import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { OperatingProfile } from './src/types/mining';
import { FleetManager } from './src/engine/fleetManager';
import { RustPerformanceEngine } from './src/engine/rustEngine';
import { REconomicsEngine } from './src/engine/rEconomics';
import { RMonteCarloEngine } from './src/engine/rMonteCarlo';
import { RSensitivityEngine } from './src/engine/rSensitivity';
import { SafeAdaptiveControlEngine } from './src/engine/adaptiveControl';

async function startServer() {
  const app = express();
  app.use(express.json());

  const PORT = 3000;

  // Global In-Memory State
  let currentProfile: OperatingProfile = 'BALANCED';
  let fleetSize = 100;
  let ambientTempC = 25.0;
  let electricityRateKWh = 0.052;
  let btcPriceUSD = 92500;
  let networkDifficulty = 85.5; // Trillions

  let cachedFleet = FleetManager.generateFleet(
    fleetSize,
    currentProfile,
    ambientTempC,
    electricityRateKWh,
    btcPriceUSD,
    networkDifficulty
  );

  // API ROUTES

  // 1. Fleet Summary
  app.get('/api/fleet/summary', (req, res) => {
    const summary = FleetManager.calculateFleetSummary(
      cachedFleet,
      btcPriceUSD,
      networkDifficulty,
      electricityRateKWh
    );
    res.json({ success: true, profile: currentProfile, summary });
  });

  // 2. Miners List
  app.get('/api/fleet/miners', (req, res) => {
    const count = parseInt(req.query.count as string) || fleetSize;
    if (count !== fleetSize) {
      fleetSize = count;
      cachedFleet = FleetManager.generateFleet(
        fleetSize,
        currentProfile,
        ambientTempC,
        electricityRateKWh,
        btcPriceUSD,
        networkDifficulty
      );
    }
    const sortBy = (req.query.sortBy as any) || 'efficiencyJTH';
    const ranked = FleetManager.rankFleet(cachedFleet, sortBy);
    res.json({ success: true, count: ranked.length, miners: ranked.slice(0, 500) }); // Cap at 500 for UI responsiveness
  });

  // 3. Update Profile or Parameters
  app.post('/api/fleet/config', (req, res) => {
    const { profile, tempC, rateKWh, btcPrice, difficulty, count } = req.body;
    if (profile) currentProfile = profile;
    if (tempC !== undefined) ambientTempC = Number(tempC);
    if (rateKWh !== undefined) electricityRateKWh = Number(rateKWh);
    if (btcPrice !== undefined) btcPriceUSD = Number(btcPrice);
    if (difficulty !== undefined) networkDifficulty = Number(difficulty);
    if (count !== undefined) fleetSize = Math.max(1, Math.min(10000, Number(count)));

    cachedFleet = FleetManager.generateFleet(
      fleetSize,
      currentProfile,
      ambientTempC,
      electricityRateKWh,
      btcPriceUSD,
      networkDifficulty
    );

    const summary = FleetManager.calculateFleetSummary(
      cachedFleet,
      btcPriceUSD,
      networkDifficulty,
      electricityRateKWh
    );

    res.json({ success: true, profile: currentProfile, summary });
  });

  // 4. Single Model Rust Optimizer
  app.post('/api/optimise/point', (req, res) => {
    const { model, profile } = req.body;
    const result = RustPerformanceEngine.optimizeOperatingPoint(
      model || 'ANTMINER_S21',
      profile || currentProfile,
      ambientTempC,
      electricityRateKWh,
      btcPriceUSD,
      networkDifficulty
    );
    res.json({ success: true, result });
  });

  // 5. Dynamic Tariff Hourly Dispatch
  app.get('/api/economics/dynamic-tariff', (req, res) => {
    const summary = FleetManager.calculateFleetSummary(
      cachedFleet,
      btcPriceUSD,
      networkDifficulty,
      electricityRateKWh
    );

    const schedule = REconomicsEngine.generateDynamicTariffDispatchSchedule(
      electricityRateKWh,
      summary.grandTotalPowerKW,
      summary.totalHashrateTH,
      btcPriceUSD,
      networkDifficulty
    );

    res.json({ success: true, baseRateKWh: electricityRateKWh, schedule });
  });

  // 6. R Monte Carlo Runner
  app.post('/api/monte-carlo/run', (req, res) => {
    const {
      simulationsCount = 10000,
      timeHorizonDays = 90,
      btcPriceVolatilityPercent = 45,
      electricityRateVolPercent = 25,
      temperatureAnomalyC = 3,
    } = req.body;

    const summary = FleetManager.calculateFleetSummary(
      cachedFleet,
      btcPriceUSD,
      networkDifficulty,
      electricityRateKWh
    );

    const result = RMonteCarloEngine.runSimulation(
      {
        simulationsCount,
        timeHorizonDays,
        btcPriceMean: btcPriceUSD,
        btcPriceVolatilityPercent,
        difficultyGrowthPercentMonth: 2.5,
        electricityRateMean: electricityRateKWh,
        electricityRateVolPercent,
        temperatureAnomalyC,
      },
      summary.grandTotalPowerKW,
      summary.totalHashrateTH
    );

    res.json({ success: true, result });
  });

  // 7. R Sensitivity Metrics
  app.get('/api/sensitivity/metrics', (req, res) => {
    const metrics = RSensitivityEngine.calculateSensitivityMetrics();
    res.json({ success: true, metrics });
  });

  // 8. Safe Adaptive Control Step
  app.post('/api/control/step', (req, res) => {
    const { minerId = 'MINER-00001', model = 'ANTMINER_S21', currentFreqMHz = 820, deltaFreqMHz = 15, currentVoltageV = 12.8 } = req.body;

    const outcome = SafeAdaptiveControlEngine.executeControlCycle(
      minerId,
      model,
      currentFreqMHz,
      currentVoltageV,
      deltaFreqMHz,
      ambientTempC,
      electricityRateKWh,
      btcPriceUSD,
      networkDifficulty
    );

    res.json({ success: true, outcome });
  });

  // 9. Audit Log & Watchdog Status
  app.get('/api/control/audit-log', (req, res) => {
    res.json({
      success: true,
      auditLog: SafeAdaptiveControlEngine.getAuditLog(),
      watchdog: SafeAdaptiveControlEngine.getWatchdogState(),
    });
  });

  // Serve Frontend with Vite (Dev) or Static Files (Prod)
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Bitcoin Mining Optimisation Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
