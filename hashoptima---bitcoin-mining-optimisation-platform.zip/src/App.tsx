import React, { useState, useEffect } from 'react';
import { HeaderNav } from './components/HeaderNav';
import { FleetOverview } from './components/FleetOverview';
import { HardwareTelemetryView } from './components/HardwareTelemetryView';
import { HashratePowerOptimizer } from './components/HashratePowerOptimizer';
import { DynamicPricingDispatch } from './components/DynamicPricingDispatch';
import { MonteCarloWorkstation } from './components/MonteCarloWorkstation';
import { SobolSensitivityView } from './components/SobolSensitivityView';
import { FleetDispatchMatrix } from './components/FleetDispatchMatrix';
import { AdaptiveControlLoop } from './components/AdaptiveControlLoop';
import { RShinyDashboard } from './components/RShinyDashboard';

import { FleetSummary, HardwareModel, MinerTelemetry, OperatingProfile } from './types/mining';
import { Cpu, Zap, Activity, BarChart3, ShieldCheck, Server, LayoutGrid, Clock } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'RUST_OPTIMISER' | 'DYNAMIC_DISPATCH' | 'MONTE_CARLO' | 'SENSITIVITY' | 'FLEET_MATRIX' | 'ADAPTIVE_CONTROL' | 'R_SHINY'
  >('RUST_OPTIMISER');

  const [activeProfile, setActiveProfile] = useState<OperatingProfile>('BALANCED');
  const [fleetSize, setFleetSize] = useState<number>(100);
  const [ambientTempC, setAmbientTempC] = useState<number>(25.0);
  const [electricityRateKWh, setElectricityRateKWh] = useState<number>(0.052);
  const [btcPriceUSD, setBtcPriceUSD] = useState<number>(92500);
  const [networkDifficulty, setNetworkDifficulty] = useState<number>(85.5);

  const [summary, setSummary] = useState<FleetSummary | null>(null);
  const [sampleMiner, setSampleMiner] = useState<MinerTelemetry | null>(null);
  const [watchdogStatus, setWatchdogStatus] = useState<'HEALTHY' | 'WARNING' | 'TEMPERATURE_TRIP' | 'MANUAL_OVERRIDE'>('HEALTHY');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const fetchFleetSummary = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/fleet/summary');
      const data = await res.json();
      if (data.success) {
        setSummary(data.summary);
      }

      // Fetch sample miner
      const mRes = await fetch(`/api/fleet/miners?count=${fleetSize}`);
      const mData = await mRes.json();
      if (mData.success && mData.miners.length > 0) {
        setSampleMiner(mData.miners[0]);
      }

      // Watchdog
      const wRes = await fetch('/api/control/audit-log');
      const wData = await wRes.json();
      if (wData.success && wData.watchdog) {
        setWatchdogStatus(wData.watchdog.status);
      }
    } catch (e) {
      console.error('Error syncing telemetry:', e);
    } finally {
      setIsRefreshing(false);
    }
  };

  const syncConfig = async (newProfile?: OperatingProfile, newSize?: number, newTemp?: number, newRate?: number, newBtc?: number, newDiff?: number) => {
    try {
      const res = await fetch('/api/fleet/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile: newProfile || activeProfile,
          count: newSize || fleetSize,
          tempC: newTemp !== undefined ? newTemp : ambientTempC,
          rateKWh: newRate !== undefined ? newRate : electricityRateKWh,
          btcPrice: newBtc !== undefined ? newBtc : btcPriceUSD,
          difficulty: newDiff !== undefined ? newDiff : networkDifficulty,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSummary(data.summary);
      }
    } catch (e) {
      console.error('Config update failed:', e);
    }
  };

  useEffect(() => {
    fetchFleetSummary();
  }, []);

  const handleProfileChange = (p: OperatingProfile) => {
    setActiveProfile(p);
    syncConfig(p);
  };

  const handleFleetSizeChange = (s: number) => {
    setFleetSize(s);
    syncConfig(undefined, s);
  };

  const handleTempChange = (t: number) => {
    setAmbientTempC(t);
    syncConfig(undefined, undefined, t);
  };

  const handleRateChange = (r: number) => {
    setElectricityRateKWh(r);
    syncConfig(undefined, undefined, undefined, r);
  };

  const handleBtcChange = (b: number) => {
    setBtcPriceUSD(b);
    syncConfig(undefined, undefined, undefined, undefined, b);
  };

  const handleDifficultyChange = (d: number) => {
    setNetworkDifficulty(d);
    syncConfig(undefined, undefined, undefined, undefined, undefined, d);
  };

  return (
    <div id="app-root-container" className="min-h-screen bg-[#0B0C10] text-[#C5C6C7] font-sans selection:bg-[#66FCF1] selection:text-[#0B0C10] pb-12 flex flex-col justify-between">
      <div>
        {/* Navigation Header */}
        <HeaderNav
          activeProfile={activeProfile}
          onProfileChange={handleProfileChange}
          fleetSize={fleetSize}
          onFleetSizeChange={handleFleetSizeChange}
          ambientTempC={ambientTempC}
          onTempChange={handleTempChange}
          electricityRateKWh={electricityRateKWh}
          onRateChange={handleRateChange}
          btcPriceUSD={btcPriceUSD}
          onBtcPriceChange={handleBtcChange}
          networkDifficulty={networkDifficulty}
          onDifficultyChange={handleDifficultyChange}
          watchdogStatus={watchdogStatus}
          onRefresh={fetchFleetSummary}
          isRefreshing={isRefreshing}
        />

        <main className="max-w-7xl mx-auto px-4 pt-6 space-y-6">
          {/* Fleet KPI Overview Banner */}
          {summary && <FleetOverview summary={summary} />}

          {/* Tab Selection Bar */}
          <div className="flex items-center space-x-2 overflow-x-auto bg-[#0B0C10] p-1.5 rounded-xl border border-[#1F2833] text-xs font-mono">
            <button
              id="tab-rust-optimiser"
              onClick={() => setActiveTab('RUST_OPTIMISER')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'RUST_OPTIMISER'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>Rust Engine & Hardware</span>
            </button>

            <button
              id="tab-dynamic-dispatch"
              onClick={() => setActiveTab('DYNAMIC_DISPATCH')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'DYNAMIC_DISPATCH'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Dynamic Tariff Dispatch</span>
            </button>

            <button
              id="tab-monte-carlo"
              onClick={() => setActiveTab('MONTE_CARLO')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'MONTE_CARLO'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>R Monte Carlo (100k)</span>
            </button>

            <button
              id="tab-sensitivity"
              onClick={() => setActiveTab('SENSITIVITY')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'SENSITIVITY'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>R Sobol Sensitivity</span>
            </button>

            <button
              id="tab-fleet-matrix"
              onClick={() => setActiveTab('FLEET_MATRIX')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'FLEET_MATRIX'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <Server className="w-4 h-4" />
              <span>Fleet Matrix ({fleetSize})</span>
            </button>

            <button
              id="tab-adaptive-control"
              onClick={() => setActiveTab('ADAPTIVE_CONTROL')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'ADAPTIVE_CONTROL'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Adaptive Control</span>
            </button>

            <button
              id="tab-r-shiny"
              onClick={() => setActiveTab('R_SHINY')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold transition-all uppercase tracking-wider ${
                activeTab === 'R_SHINY'
                  ? 'bg-[#66FCF1] text-[#0B0C10] shadow-[0_0_12px_rgba(102,252,241,0.4)]'
                  : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/40'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span>R Shiny Workstation</span>
            </button>
          </div>

          {/* Tab Content Display */}
          {activeTab === 'RUST_OPTIMISER' && (
            <div className="space-y-6">
              <HashratePowerOptimizer
                model="ANTMINER_S21"
                profile={activeProfile}
                ambientTempC={ambientTempC}
                electricityRateKWh={electricityRateKWh}
                btcPriceUSD={btcPriceUSD}
                networkDifficulty={networkDifficulty}
              />
              {sampleMiner && (
                <HardwareTelemetryView
                  sampleMiner={sampleMiner}
                  onModelSelect={(m) => {
                    /* Selected driver model */
                  }}
                />
              )}
            </div>
          )}

          {activeTab === 'DYNAMIC_DISPATCH' && summary && (
            <DynamicPricingDispatch
              summary={summary}
              electricityRateKWh={electricityRateKWh}
              btcPriceUSD={btcPriceUSD}
              networkDifficulty={networkDifficulty}
            />
          )}

          {activeTab === 'MONTE_CARLO' && summary && (
            <MonteCarloWorkstation
              basePowerKW={summary.grandTotalPowerKW}
              baseHashrateTH={summary.totalHashrateTH}
              btcPriceUSD={btcPriceUSD}
              electricityRateKWh={electricityRateKWh}
            />
          )}

          {activeTab === 'SENSITIVITY' && <SobolSensitivityView />}

          {activeTab === 'FLEET_MATRIX' && (
            <FleetDispatchMatrix
              fleetSize={fleetSize}
              activeProfile={activeProfile}
              onRefresh={fetchFleetSummary}
            />
          )}

          {activeTab === 'ADAPTIVE_CONTROL' && <AdaptiveControlLoop />}

          {activeTab === 'R_SHINY' && summary && (
            <RShinyDashboard
              summary={summary}
              btcPriceUSD={btcPriceUSD}
              electricityRateKWh={electricityRateKWh}
              networkDifficulty={networkDifficulty}
            />
          )}
        </main>
      </div>

      {/* Bento Grid Footer Bar */}
      <footer id="bento-footer" className="bg-[#0B0C10] border-t border-[#1F2833] px-6 py-3 flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-[#45A29E] font-mono mt-12 max-w-7xl mx-auto w-full">
        <span>HASHOPTIMA RUST/R CONTROL PLATFORM</span>
        <span className="flex items-center space-x-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#66FCF1] animate-ping"></span>
          <span>SHA-256 ASIC TELEMETRY SYNCED</span>
        </span>
      </footer>
    </div>
  );
}
