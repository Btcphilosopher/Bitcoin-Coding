import React, { useState, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, RotateCcw, Activity, Play, CheckCircle2, XCircle, FileText, Lock } from 'lucide-react';
import { AdaptiveControlStep, HardwareModel } from '../types/mining';

export const AdaptiveControlLoop: React.FC = () => {
  const [stepLog, setStepLog] = useState<AdaptiveControlStep[]>([]);
  const [watchdogStatus, setWatchdogStatus] = useState<any>(null);
  const [deltaFreq, setDeltaFreq] = useState<number>(15);
  const [selectedMinerId, setSelectedMinerId] = useState<string>('MINER-00001');
  const [isRunningStep, setIsRunningStep] = useState<boolean>(false);

  const fetchAuditLog = async () => {
    try {
      const res = await fetch('/api/control/audit-log');
      const data = await res.json();
      if (data.success) {
        setStepLog(data.auditLog);
        setWatchdogStatus(data.watchdog);
      }
    } catch (e) {
      console.error('Audit log fetch error:', e);
    }
  };

  useEffect(() => {
    fetchAuditLog();
  }, []);

  const triggerControlCycle = async () => {
    setIsRunningStep(true);
    try {
      const res = await fetch('/api/control/step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          minerId: selectedMinerId,
          model: 'ANTMINER_S21',
          currentFreqMHz: 820,
          deltaFreqMHz: deltaFreq,
          currentVoltageV: 12.8,
        }),
      });
      const data = await res.json();
      if (data.success) {
        fetchAuditLog();
      }
    } catch (e) {
      console.error('Control cycle error:', e);
    } finally {
      setIsRunningStep(false);
    }
  };

  return (
    <section id="adaptive-control-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">Safe Adaptive Closed-Loop Controller</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            OBSERVE → SIMULATE → PREDICT → MAKE SMALL CHANGE → OBSERVE → COMPARE → ACCEPT / REVERT
          </p>
        </div>

        {/* Step Execution Trigger Controls */}
        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="flex items-center space-x-2 bg-[#0B0C10] px-3 py-1.5 rounded-lg border border-[#1F2833]">
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider">Step Step Size:</span>
            <input
              id="delta-freq-input"
              type="number"
              value={deltaFreq}
              onChange={(e) => setDeltaFreq(parseInt(e.target.value) || 10)}
              className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-[#66FCF1] w-16 text-right outline-none font-bold"
            />
            <span className="text-gray-400">MHz</span>
          </div>

          <button
            id="trigger-adaptive-step-btn"
            onClick={triggerControlCycle}
            disabled={isRunningStep}
            className="flex items-center space-x-1.5 bg-[#66FCF1] text-[#0B0C10] hover:bg-[#45A29E] px-3 py-1.5 rounded-lg font-mono font-bold transition shadow-[0_0_10px_rgba(102,252,241,0.4)]"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Execute 1 Step</span>
          </button>
        </div>
      </div>

      {/* Control Loop State Diagram */}
      <div className="grid grid-cols-2 md:grid-cols-7 gap-2 font-mono text-[11px] text-center">
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-[#66FCF1] font-bold mb-1 uppercase tracking-wider text-[10px]">1. OBSERVE</div>
          <div>Telemetry Poll</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-sky-400 font-bold mb-1 uppercase tracking-wider text-[10px]">2. SIMULATE</div>
          <div>Silicon Model</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-[#45A29E] font-bold mb-1 uppercase tracking-wider text-[10px]">3. PREDICT</div>
          <div>Thermal Risk</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-[#C34133] font-bold mb-1 uppercase tracking-wider text-[10px]">4. SMALL CHANGE</div>
          <div>±10-15 MHz</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-[#66FCF1] font-bold mb-1 uppercase tracking-wider text-[10px]">5. OBSERVE POST</div>
          <div>HW Errors & Temp</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300">
          <div className="text-sky-400 font-bold mb-1 uppercase tracking-wider text-[10px]">6. COMPARE</div>
          <div>Profit Delta</div>
        </div>
        <div className="bg-[#0B0C10] p-2.5 rounded-lg border border-[#1F2833] text-slate-300 col-span-2 md:col-span-1">
          <div className="text-[#66FCF1] font-bold mb-1 uppercase tracking-wider text-[10px]">7. COMMIT / REVERT</div>
          <div>Watchdog Safety</div>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="space-y-2 font-mono">
        <div className="flex items-center space-x-2 text-xs text-slate-200 font-semibold uppercase tracking-wider text-[11px]">
          <FileText className="w-4 h-4 text-[#66FCF1]" />
          <span>Configuration Change Ledger & Audit Trail ({stepLog.length} events logged)</span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-[#1F2833] bg-[#0B0C10] text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#1F2833]/40 border-b border-[#1F2833] text-[#45A29E] text-[10px] uppercase tracking-wider">
                <th className="p-2.5">TIMESTAMP</th>
                <th className="p-2.5">MINER ID</th>
                <th className="p-2.5">PHASE</th>
                <th className="p-2.5">PREV → PROPOSED</th>
                <th className="p-2.5">ACTUAL HASHRATE</th>
                <th className="p-2.5">ACTUAL TEMP</th>
                <th className="p-2.5">DECISION & REASON</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2833]/60">
              {stepLog.map((step) => (
                <tr key={step.stepId} className="hover:bg-[#1F2833]/20 transition">
                  <td className="p-2.5 text-gray-400">{new Date(step.timestamp).toLocaleTimeString()}</td>
                  <td className="p-2.5 font-bold text-[#66FCF1]">{step.minerId}</td>
                  <td className="p-2.5 font-bold text-sky-400">{step.phase}</td>
                  <td className="p-2.5 text-slate-300">{step.previousValue} MHz → <span className="text-[#66FCF1] font-bold">{step.proposedValue} MHz</span></td>
                  <td className="p-2.5 text-slate-200">{step.actualHashrateTH ?? '-'} TH/s</td>
                  <td className="p-2.5 text-[#C34133]">{step.actualTempC ?? '-'} °C</td>
                  <td className="p-2.5">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          step.decision === 'ACCEPTED'
                            ? 'bg-[#45A29E]/20 text-[#66FCF1] border border-[#45A29E]/40'
                            : 'bg-[#C34133]/20 text-[#C34133] border border-[#C34133]/40'
                        }`}
                      >
                        {step.decision}
                      </span>
                      <span className="text-[11px] text-gray-400 truncate max-w-xs">{step.reason}</span>
                    </div>
                  </td>
                </tr>
              ))}
              {stepLog.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-4 text-center text-gray-500">
                    No control steps recorded yet. Click "Execute 1 Step" above to initiate a safe tuning cycle.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
