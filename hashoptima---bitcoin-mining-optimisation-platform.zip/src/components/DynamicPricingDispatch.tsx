import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, Cell } from 'recharts';
import { Zap, Clock, DollarSign, Activity, AlertTriangle, ShieldCheck } from 'lucide-react';
import { DispatchState, DynamicHourlyTariff, FleetSummary } from '../types/mining';
import { REconomicsEngine } from '../engine/rEconomics';

interface DynamicPricingDispatchProps {
  summary: FleetSummary;
  electricityRateKWh: number;
  btcPriceUSD: number;
  networkDifficulty: number;
}

export const DynamicPricingDispatch: React.FC<DynamicPricingDispatchProps> = ({
  summary,
  electricityRateKWh,
  btcPriceUSD,
  networkDifficulty,
}) => {
  const [profitMarginThresholdUSD, setProfitMarginThresholdUSD] = useState<number>(0.02);
  const [schedule, setSchedule] = useState<DynamicHourlyTariff[]>([]);

  useEffect(() => {
    const data = REconomicsEngine.generateDynamicTariffDispatchSchedule(
      electricityRateKWh,
      summary.grandTotalPowerKW,
      summary.totalHashrateTH,
      btcPriceUSD,
      networkDifficulty,
      profitMarginThresholdUSD
    );
    setSchedule(data);
  }, [electricityRateKWh, summary.grandTotalPowerKW, summary.totalHashrateTH, btcPriceUSD, networkDifficulty, profitMarginThresholdUSD]);

  const getStateColor = (state: DispatchState) => {
    switch (state) {
      case 'FULL_POWER': return '#66FCF1'; // Bright Cyan
      case 'REDUCED_POWER': return '#45A29E'; // Muted Teal
      case 'STANDBY': return '#38bdf8'; // Sky
      case 'OFFLINE': return '#C34133'; // Red
    }
  };

  const activeHoursCount = schedule.filter((s) => s.recommendedState === 'FULL_POWER').length;
  const reducedHoursCount = schedule.filter((s) => s.recommendedState === 'REDUCED_POWER').length;
  const curtailedHoursCount = schedule.filter((s) => s.recommendedState === 'OFFLINE' || s.recommendedState === 'STANDBY').length;

  const total24hProfitUSD = schedule.reduce((acc, s) => acc + (s.recommendedState === 'OFFLINE' ? 0 : s.expectedProfitUSD), 0);

  return (
    <section id="dynamic-pricing-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">Dynamic Electricity Tariff & Automated Fleet Dispatch</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            24-Hour Spot Price Curve Dispatch Engine (FULL POWER / REDUCED / STANDBY / OFFLINE)
          </p>
        </div>

        {/* Profit Threshold Control */}
        <div className="flex items-center space-x-3 bg-[#0B0C10] px-3 py-1.5 rounded-lg border border-[#1F2833] font-mono text-xs">
          <span className="text-[#45A29E] uppercase tracking-wider text-[10px]">Min Profit Threshold:</span>
          <input
            id="input-profit-threshold"
            type="number"
            step="0.01"
            value={profitMarginThresholdUSD}
            onChange={(e) => setProfitMarginThresholdUSD(parseFloat(e.target.value) || 0)}
            className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-[#66FCF1] w-16 text-right outline-none font-bold"
          />
          <span className="text-gray-400">$/TH/day</span>
        </div>
      </div>

      {/* 24h Summary Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">24h Full Power Hours</div>
          <div className="text-base font-bold text-[#66FCF1]">{activeHoursCount} Hours</div>
          <div className="text-[10px] text-gray-500">Unconstrained mining</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">24h Reduced Power Hours</div>
          <div className="text-base font-bold text-[#45A29E]">{reducedHoursCount} Hours</div>
          <div className="text-[10px] text-gray-500">Under-clocked efficiency</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">24h Curtailed / Off Hours</div>
          <div className="text-base font-bold text-[#C34133]">{curtailedHoursCount} Hours</div>
          <div className="text-[10px] text-gray-500">Avoided peak losses</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">24h Optimized Fleet Profit</div>
          <div className="text-base font-bold text-[#66FCF1]">${total24hProfitUSD.toFixed(2)}</div>
          <div className="text-[10px] text-gray-500">Net daily forecast</div>
        </div>
      </div>

      {/* Hourly Electricity Tariff Bar Chart */}
      <div className="space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-200 font-semibold uppercase tracking-wider text-[11px]">
            24-Hour Electricity Tariff ($/kWh) & Automated Dispatch Decisions
          </span>
          <div className="flex items-center space-x-3 text-[10px] uppercase tracking-wider">
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#66FCF1]"></span><span>Full</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#45A29E]"></span><span>Reduced</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span><span>Standby</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#C34133]"></span><span>Offline</span></span>
          </div>
        </div>

        <div className="h-64 w-full bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833] text-xs">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={schedule} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
              <XAxis dataKey="hour" stroke="#45A29E" tickFormatter={(h) => `${String(h).padStart(2, '0')}:00`} />
              <YAxis stroke="#66FCF1" unit=" $" />
              <Tooltip
                contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }}
                formatter={(val: any, name: any) => [name === 'electricityRateKWh' ? `$${val}/kWh` : `$${val}`, name]}
                labelFormatter={(h) => `Hour ${String(h).padStart(2, '0')}:00`}
              />
              <Bar dataKey="electricityRateKWh" name="Tariff ($/kWh)">
                {schedule.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getStateColor(entry.recommendedState)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Dispatch Schedule Matrix Table */}
      <div className="overflow-x-auto rounded-xl border border-[#1F2833] bg-[#0B0C10] font-mono text-xs">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#1F2833]/40 border-b border-[#1F2833] text-[#45A29E] text-[10px] uppercase tracking-wider">
              <th className="p-2.5">HOUR</th>
              <th className="p-2.5">TARIFF ($/kWh)</th>
              <th className="p-2.5">REVENUE/HR</th>
              <th className="p-2.5">POWER COST/HR</th>
              <th className="p-2.5">NET PROFIT/HR</th>
              <th className="p-2.5">RECOMMENDED DISPATCH</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1F2833]/60">
            {schedule.slice(0, 12).map((s) => (
              <tr key={s.hour} className="hover:bg-[#1F2833]/20 transition">
                <td className="p-2.5 font-bold text-white">{String(s.hour).padStart(2, '0')}:00</td>
                <td className="p-2.5 text-[#45A29E]">${s.electricityRateKWh}</td>
                <td className="p-2.5 text-gray-300">${s.expectedRevenueUSD}</td>
                <td className="p-2.5 text-gray-300">${s.expectedPowerCostUSD}</td>
                <td className={`p-2.5 font-bold ${s.expectedProfitUSD >= 0 ? 'text-[#66FCF1]' : 'text-[#C34133]'}`}>
                  ${s.expectedProfitUSD}
                </td>
                <td className="p-2.5">
                  <span
                    className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: `${getStateColor(s.recommendedState)}20`,
                      color: getStateColor(s.recommendedState),
                      border: `1px solid ${getStateColor(s.recommendedState)}60`,
                    }}
                  >
                    {s.recommendedState}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};
