import React, { useState, useEffect } from 'react';
import { Server, ArrowUpDown, Filter, ShieldAlert, Zap, RefreshCw, Layers } from 'lucide-react';
import { MinerTelemetry, OperatingProfile } from '../types/mining';

interface FleetDispatchMatrixProps {
  fleetSize: number;
  activeProfile: OperatingProfile;
  onRefresh: () => void;
}

export const FleetDispatchMatrix: React.FC<FleetDispatchMatrixProps> = ({ fleetSize, activeProfile, onRefresh }) => {
  const [miners, setMiners] = useState<MinerTelemetry[]>([]);
  const [sortBy, setSortBy] = useState<keyof MinerTelemetry>('efficiencyJTH');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const fetchMiners = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/fleet/miners?count=${fleetSize}&sortBy=${sortBy}`);
      const data = await res.json();
      if (data.success) {
        setMiners(data.miners);
      }
    } catch (err) {
      console.error('Error fetching fleet miners:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMiners();
  }, [fleetSize, sortBy, activeProfile]);

  const filteredMiners = miners.filter(
    (m) =>
      m.minerId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.ipAddress.includes(searchTerm)
  );

  return (
    <section id="fleet-dispatch-matrix-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Server className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">Multi-Miner Fleet Dispatch Matrix</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            Unit-Level Silicon Binning & Ranking ({miners.length} / {fleetSize} miners shown)
          </p>
        </div>

        {/* Search & Sort Controls */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="flex items-center bg-[#0B0C10] border border-[#1F2833] rounded-lg px-2.5 py-1 text-slate-300">
            <Filter className="w-3.5 h-3.5 text-[#45A29E] mr-2" />
            <input
              id="fleet-search-input"
              type="text"
              placeholder="Search ID, IP, Model..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-xs w-36 text-white placeholder:text-gray-600"
            />
          </div>

          <div className="flex items-center bg-[#0B0C10] border border-[#1F2833] rounded-lg px-2.5 py-1 text-slate-300">
            <ArrowUpDown className="w-3.5 h-3.5 text-[#66FCF1] mr-2" />
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider mr-2">Sort:</span>
            <select
              id="fleet-sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as keyof MinerTelemetry)}
              className="bg-[#1F2833]/60 text-[#66FCF1] border border-[#45A29E]/30 rounded px-1.5 py-0.5 outline-none font-bold"
            >
              <option value="efficiencyJTH">J/TH (Efficiency)</option>
              <option value="effectiveHashrateTH">Hashrate (TH/s)</option>
              <option value="maxASICTempC">ASIC Temp (°C)</option>
              <option value="failureRiskPercent">Failure Risk (%)</option>
              <option value="hardwareErrorRate">HW Error Rate</option>
            </select>
          </div>

          <button
            id="refresh-fleet-btn"
            onClick={fetchMiners}
            className="p-1.5 bg-[#0B0C10] hover:bg-[#1F2833] rounded-lg border border-[#1F2833] text-[#66FCF1] transition"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Fleet Table */}
      <div className="overflow-x-auto rounded-xl border border-[#1F2833] bg-[#0B0C10] font-mono text-xs">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#1F2833]/40 border-b border-[#1F2833] text-[#45A29E] text-[10px] uppercase tracking-wider">
              <th className="p-2.5">MINER ID</th>
              <th className="p-2.5">MODEL & IP</th>
              <th className="p-2.5">DISPATCH STATE</th>
              <th className="p-2.5">HASHRATE</th>
              <th className="p-2.5">POWER</th>
              <th className="p-2.5">J / TH</th>
              <th className="p-2.5">ASIC TEMP</th>
              <th className="p-2.5">FAN RPM</th>
              <th className="p-2.5">SILICON SCORE</th>
              <th className="p-2.5">FAILURE RISK</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1F2833]/60">
            {filteredMiners.slice(0, 50).map((miner) => (
              <tr key={miner.minerId} className="hover:bg-[#1F2833]/20 transition">
                <td className="p-2.5 font-bold text-[#66FCF1]">{miner.minerId}</td>
                <td className="p-2.5 text-slate-200">
                  <div className="font-bold">{miner.model.replace(/_/g, ' ')}</div>
                  <div className="text-[10px] text-gray-500">{miner.ipAddress}</div>
                </td>
                <td className="p-2.5">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      miner.dispatchState === 'FULL_POWER'
                        ? 'bg-[#45A29E]/20 text-[#66FCF1] border border-[#45A29E]/40'
                        : miner.dispatchState === 'REDUCED_POWER'
                        ? 'bg-[#45A29E]/10 text-[#45A29E] border border-[#45A29E]/30'
                        : 'bg-[#C34133]/20 text-[#C34133] border border-[#C34133]/40'
                    }`}
                  >
                    {miner.dispatchState}
                  </span>
                </td>
                <td className="p-2.5 font-bold text-white">{miner.effectiveHashrateTH} TH/s</td>
                <td className="p-2.5 text-gray-300">{miner.totalPowerW} W</td>
                <td className="p-2.5 font-bold text-[#66FCF1]">{miner.efficiencyJTH} J/TH</td>
                <td className="p-2.5 font-bold text-[#C34133]">{miner.maxASICTempC} °C</td>
                <td className="p-2.5 text-gray-400">{miner.fanSpeedRPM} RPM ({miner.fanSpeedPercent}%)</td>
                <td className="p-2.5 text-sky-400 font-bold">{miner.siliconQualityScore}x</td>
                <td className="p-2.5">
                  <div className="flex items-center space-x-1.5">
                    <span
                      className={`font-bold ${
                        miner.failureRiskPercent > 30 ? 'text-[#C34133]' : 'text-[#66FCF1]'
                      }`}
                    >
                      {miner.failureRiskPercent}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};
