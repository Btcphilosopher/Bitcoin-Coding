import React from 'react';
import { Cpu, Zap, Activity, DollarSign, Flame, AlertCircle, CheckCircle2, TrendingUp, BarChart3 } from 'lucide-react';
import { FleetSummary } from '../types/mining';

interface FleetOverviewProps {
  summary: FleetSummary;
}

export const FleetOverview: React.FC<FleetOverviewProps> = ({ summary }) => {
  const hashRateDisplay = summary.totalHashrateTH >= 1000
    ? `${(summary.totalHashrateTH / 1000).toFixed(2)} PH/s`
    : `${summary.totalHashrateTH.toLocaleString()} TH/s`;

  const powerDisplay = summary.grandTotalPowerKW >= 1000
    ? `${(summary.grandTotalPowerKW / 1000).toFixed(2)} MW`
    : `${summary.grandTotalPowerKW.toLocaleString()} kW`;

  return (
    <section id="fleet-overview-section" className="space-y-4">
      {/* Top Level Metric Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 font-mono">
        {/* Total Hashrate */}
        <div id="metric-card-hashrate" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>Total Hashrate</span>
            <Cpu className="w-4 h-4 text-[#66FCF1]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#66FCF1]">{hashRateDisplay}</div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">Effective SHA-256 Output</div>
        </div>

        {/* Total Power */}
        <div id="metric-card-power" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>Total Power</span>
            <Zap className="w-4 h-4 text-[#C34133]" />
          </div>
          <div className="text-2xl font-mono font-bold text-white">{powerDisplay}</div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">
            Mining: {summary.totalPowerKW} kW | PUE: {summary.coolingPowerKW + summary.facilityOverheadKW} kW
          </div>
        </div>

        {/* Average Efficiency J/TH */}
        <div id="metric-card-efficiency" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>Average J/TH</span>
            <Activity className="w-4 h-4 text-[#66FCF1]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#66FCF1]">{summary.effectiveEfficiencyJTH} <span className="text-xs text-[#45A29E] font-normal">J/TH</span></div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">Energy per TeraHash</div>
        </div>

        {/* Net Daily Profit */}
        <div id="metric-card-net-profit" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>Net Profit / Day</span>
            <DollarSign className="w-4 h-4 text-[#66FCF1]" />
          </div>
          <div className={`text-2xl font-mono font-bold ${summary.dailyNetProfitUSD >= 0 ? 'text-[#66FCF1]' : 'text-[#C34133]'}`}>
            ${summary.dailyNetProfitUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">Net after power & overhead</div>
        </div>

        {/* Daily BTC Mined */}
        <div id="metric-card-daily-btc" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>BTC / Day</span>
            <TrendingUp className="w-4 h-4 text-[#66FCF1]" />
          </div>
          <div className="text-2xl font-mono font-bold text-white">
            {summary.dailyBtcMined} <span className="text-xs text-[#66FCF1] font-normal">BTC</span>
          </div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">Revenue: ${summary.dailyRevenueUSD.toLocaleString()}</div>
        </div>

        {/* Average Temperature */}
        <div id="metric-card-temp" className="bg-[#1F2833]/40 border border-[#1F2833] p-4 rounded-xl space-y-2 shadow-sm hover:border-[#45A29E]/40 transition">
          <div className="flex items-center justify-between text-[#45A29E] text-[10px] uppercase tracking-widest font-mono">
            <span>Avg ASIC Temp</span>
            <Flame className="w-4 h-4 text-[#C34133]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#C34133]">{summary.averageASICTempC} °C</div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">Error Rate: {summary.averageErrorRate}%</div>
        </div>
      </div>

      {/* Dispatch Fleet Status Banner */}
      <div className="bg-[#0B0C10] border border-[#1F2833] p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-4 h-4 text-[#66FCF1]" />
          <span className="text-[#45A29E] font-semibold text-[10px] uppercase tracking-widest">Fleet Dispatch Status:</span>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center space-x-1.5 bg-[#45A29E]/10 border border-[#45A29E]/30 px-3 py-1 rounded-lg text-[#66FCF1]">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#66FCF1]" />
            <span>FULL POWER: <strong>{summary.activeCount}</strong></span>
          </div>

          <div className="flex items-center space-x-1.5 bg-amber-950/40 border border-amber-800/40 px-3 py-1 rounded-lg text-amber-300">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>REDUCED POWER: <strong>{summary.reducedPowerCount}</strong></span>
          </div>

          <div className="flex items-center space-x-1.5 bg-[#1F2833]/60 border border-[#1F2833] px-3 py-1 rounded-lg text-gray-300">
            <Activity className="w-3.5 h-3.5 text-[#45A29E]" />
            <span>STANDBY: <strong>{summary.standbyCount}</strong></span>
          </div>

          <div className="flex items-center space-x-1.5 bg-[#C34133]/20 border border-[#C34133]/40 px-3 py-1 rounded-lg text-[#C34133]">
            <AlertCircle className="w-3.5 h-3.5 text-[#C34133]" />
            <span>OFFLINE: <strong>{summary.offlineCount}</strong></span>
          </div>
        </div>

        <div className="text-[#45A29E] text-right text-xs">
          Total Fleet: <span className="text-white font-bold">{summary.totalMinersCount}</span> units
        </div>
      </div>
    </section>
  );
};
