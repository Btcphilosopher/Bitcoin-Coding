import React, { useState } from 'react';
import { Cpu, Server, Thermometer, ShieldAlert, CheckCircle2, Code2, Fan, Activity, Layers } from 'lucide-react';
import { HardwareModel, MinerTelemetry } from '../types/mining';
import { HARDWARE_SPECS, buildModelControlPayload } from '../engine/hardware';

interface HardwareTelemetryViewProps {
  sampleMiner: MinerTelemetry;
  onModelSelect: (model: HardwareModel) => void;
}

export const HardwareTelemetryView: React.FC<HardwareTelemetryViewProps> = ({ sampleMiner, onModelSelect }) => {
  const [selectedModel, setSelectedModel] = useState<HardwareModel>(sampleMiner.model);
  const spec = HARDWARE_SPECS[selectedModel];

  const handleModelChange = (model: HardwareModel) => {
    setSelectedModel(model);
    onModelSelect(model);
  };

  const payload = buildModelControlPayload(
    selectedModel,
    spec.nominalFreqMHz,
    spec.minVoltageV + 1.2,
    75
  );

  return (
    <section id="hardware-telemetry-view" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header & Driver Model Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Server className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">ASIC Hardware Abstraction Driver</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            Model-Specific Control Protocols & Board Register Telemetry (Bitmain Antminer & Whatsminer)
          </p>
        </div>

        {/* Driver Selector Pills */}
        <div className="flex flex-wrap gap-2">
          {(Object.keys(HARDWARE_SPECS) as HardwareModel[]).map((m) => (
            <button
              key={m}
              id={`driver-model-select-${m}`}
              onClick={() => handleModelChange(m)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider transition-all ${
                selectedModel === m
                  ? 'bg-[#66FCF1] text-[#0B0C10] font-bold shadow-[0_0_10px_rgba(102,252,241,0.4)]'
                  : 'bg-[#0B0C10] text-[#45A29E] border border-[#1F2833] hover:text-[#66FCF1]'
              }`}
            >
              {HARDWARE_SPECS[m].displayName.split(' (')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Model Spec Grid & Capabilities */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Nominal Hashrate</div>
          <div className="text-base font-bold text-[#66FCF1]">{spec.nominalHashrateTH} TH/s</div>
          <div className="text-[10px] text-gray-500">{spec.coolingType} Cooling</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Nominal Efficiency</div>
          <div className="text-base font-bold text-[#66FCF1]">{spec.nominalEfficiencyJTH} J/TH</div>
          <div className="text-[10px] text-gray-500">Rated {spec.nominalPowerW}W</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Hash Boards / Chips</div>
          <div className="text-base font-bold text-sky-400">{spec.hashBoardsCount} Boards</div>
          <div className="text-[10px] text-gray-500">{spec.chipsPerBoard} Chips/Board ({spec.hashBoardsCount * spec.chipsPerBoard} total)</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Frequency Window</div>
          <div className="text-base font-bold text-[#45A29E]">{spec.minFreqMHz} - {spec.maxFreqMHz} MHz</div>
          <div className="text-[10px] text-gray-500">Nominal: {spec.nominalFreqMHz} MHz</div>
        </div>

        <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
          <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Max Temp Limits</div>
          <div className="text-base font-bold text-[#C34133]">ASIC: {spec.maxTempASICC}°C</div>
          <div className="text-[10px] text-gray-500">PCB: {spec.maxTempPCBC}°C</div>
        </div>
      </div>

      {/* Hashboard Telemetry Grid & Thermal Map */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center space-x-2 text-slate-200 font-semibold">
            <Layers className="w-4 h-4 text-[#66FCF1]" />
            <span className="uppercase text-[11px] tracking-wider">Hashboard Register Status & Thermal Map ({selectedModel})</span>
          </div>
          <span className="text-[#45A29E] text-[10px]">IP: {sampleMiner.ipAddress} | FW: {spec.firmwareSupport[0]}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sampleMiner.boards.slice(0, spec.hashBoardsCount).map((board) => (
            <div key={board.boardId} className="bg-[#0B0C10] border border-[#1F2833] p-4 rounded-xl space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-[#1F2833] pb-2">
                <span className="font-bold text-white uppercase tracking-wider">BOARD #{board.boardId}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  board.status === 'OK' ? 'bg-[#45A29E]/10 text-[#66FCF1] border border-[#45A29E]/30' : 'bg-[#C34133]/20 text-[#C34133] border border-[#C34133]/40'
                }`}>
                  {board.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-[#45A29E] text-[10px] uppercase">ASIC Temp:</span>
                  <div className="text-sm font-bold text-[#C34133]">{board.temperatureASIC} °C</div>
                </div>
                <div>
                  <span className="text-[#45A29E] text-[10px] uppercase">PCB Temp:</span>
                  <div className="text-sm font-bold text-[#45A29E]">{board.temperaturePCB} °C</div>
                </div>
                <div>
                  <span className="text-[#45A29E] text-[10px] uppercase">Frequency:</span>
                  <div className="text-white font-bold">{board.frequencyMHz} MHz</div>
                </div>
                <div>
                  <span className="text-[#45A29E] text-[10px] uppercase">Voltage:</span>
                  <div className="text-white font-bold">{board.voltageV} V</div>
                </div>
              </div>

              {/* Active Chip Health Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-[#45A29E] uppercase">
                  <span>Active Chips ({board.chipCountActive}/{board.chipCountTotal})</span>
                  <span>HW Errors: {board.hardwareErrors}</span>
                </div>
                <div className="h-2 w-full bg-[#1F2833] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#66FCF1] rounded-full"
                    style={{ width: `${(board.chipCountActive / board.chipCountTotal) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Model-Specific API Control Protocol Payload Inspector */}
      <div className="bg-[#0B0C10] border border-[#1F2833] p-4 rounded-xl space-y-2 font-mono text-xs">
        <div className="flex items-center space-x-2 text-slate-200 font-semibold">
          <Code2 className="w-4 h-4 text-sky-400" />
          <span className="uppercase text-[11px] tracking-wider">Model-Specific Firmware Control Command (Low-Level API Register Payload)</span>
        </div>
        <p className="text-[10px] text-[#45A29E] uppercase tracking-wider">
          Different ASIC models (S19 Pro vs S21 vs Whatsminer) utilize distinct protocol payloads and control registers.
        </p>
        <pre className="bg-[#1F2833]/40 border border-[#1F2833] p-3 rounded-lg text-[#66FCF1] text-[11px] overflow-x-auto">
          {JSON.stringify(payload, null, 2)}
        </pre>
      </div>
    </section>
  );
};
