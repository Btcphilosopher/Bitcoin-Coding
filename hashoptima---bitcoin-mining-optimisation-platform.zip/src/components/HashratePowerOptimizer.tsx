import React, { useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { Cpu, Zap, Flame, Sliders, CheckCircle, ShieldAlert } from 'lucide-react';
import { HardwareModel, OperatingProfile, OptimizationTargetOutput } from '../types/mining';
import { HARDWARE_SPECS } from '../engine/hardware';
import { RustPerformanceEngine } from '../engine/rustEngine';

interface HashratePowerOptimizerProps {
  model: HardwareModel;
  profile: OperatingProfile;
  ambientTempC: number;
  electricityRateKWh: number;
  btcPriceUSD: number;
  networkDifficulty: number;
}

export const HashratePowerOptimizer: React.FC<HashratePowerOptimizerProps> = ({
  model,
  profile,
  ambientTempC,
  electricityRateKWh,
  btcPriceUSD,
  networkDifficulty,
}) => {
  const [freqSweepMHz, setFreqSweepMHz] = useState<number>(HARDWARE_SPECS[model].nominalFreqMHz);
  const spec = HARDWARE_SPECS[model];

  // Run Optimizer for current profile
  const optResult: OptimizationTargetOutput = RustPerformanceEngine.optimizeOperatingPoint(
    model,
    profile,
    ambientTempC,
    electricityRateKWh,
    btcPriceUSD,
    networkDifficulty
  );

  // Generate Frequency Sweep Curve Data (demonstrating diminishing economic returns)
  const sweepData = [];
  const minF = spec.minFreqMHz;
  const maxF = spec.maxFreqMHz;
  const step = (maxF - minF) / 12;

  for (let f = minF; f <= maxF; f += step) {
    const volt = spec.minVoltageV + (f - spec.minFreqMHz) * 0.006 + 0.2;
    const perf = RustPerformanceEngine.calculatePerformance({
      model,
      frequencyMHz: f,
      voltageV: volt,
      ambientTempC,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 180,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });

    sweepData.push({
      freqMHz: Math.round(f),
      hashrateTH: Number(perf.effectiveHashrateTH.toFixed(1)),
      powerW: Math.round(perf.totalPowerW),
      efficiencyJTH: Number(perf.efficiencyJTH.toFixed(1)),
      netProfitUSD: Number(perf.dailyNetProfitUSD.toFixed(2)),
      asicTempC: Number(perf.asicTempC.toFixed(1)),
    });
  }

  // Selected Frequency calculation details
  const selectedVolt = spec.minVoltageV + (freqSweepMHz - spec.minFreqMHz) * 0.006 + 0.2;
  const currentPerf = RustPerformanceEngine.calculatePerformance({
    model,
    frequencyMHz: freqSweepMHz,
    voltageV: selectedVolt,
    ambientTempC,
    fanSpeedPercent: 80,
    siliconQualityScore: 1.0,
    ageDays: 180,
    btcPriceUSD,
    electricityRateKWh,
    networkDifficulty,
  });

  return (
    <section id="rust-optimizer-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Title & Description */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">Rust Real-Time Optimisation Engine</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            Frequency / Voltage Silicon Curve & Diminishing Economic Returns Analysis
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-[#0B0C10] px-3 py-1.5 rounded-lg border border-[#1F2833] font-mono text-xs">
          <span className="text-[#45A29E] uppercase tracking-wider text-[10px]">Target Profile:</span>
          <span className="text-[#66FCF1] font-bold uppercase">{profile}</span>
        </div>
      </div>

      {/* Recommended Operating Point Summary Cards */}
      <div className="bg-[#0B0C10] border border-[#1F2833] p-4 rounded-xl space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between text-[#66FCF1] font-bold text-sm">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-[#66FCF1]" />
            <span className="uppercase text-xs tracking-wide">Optimal Sustained Operating Point ({spec.displayName})</span>
          </div>
          <span className="text-[10px] text-[#45A29E] font-normal tracking-wider">
            95% Confidence Interval: [${optResult.confidenceInterval95[0]} - ${optResult.confidenceInterval95[1]}/day]
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 pt-1">
          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Target Freq</div>
            <div className="text-base font-bold text-[#66FCF1]">{optResult.targetFreqMHz} MHz</div>
            <div className="text-[10px] text-gray-500">{optResult.targetVoltageV} V</div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Target Hashrate</div>
            <div className="text-base font-bold text-white">{optResult.targetHashrateTH} TH/s</div>
            <div className="text-[10px] text-gray-500">Effective SHA-256</div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Target Power</div>
            <div className="text-base font-bold text-sky-400">{optResult.targetPowerW} W</div>
            <div className="text-[10px] text-gray-500">Fan: {optResult.targetFanRPM} RPM</div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Expected Efficiency</div>
            <div className="text-base font-bold text-[#66FCF1]">{optResult.expectedJTH} J/TH</div>
            <div className="text-[10px] text-gray-500">Facility Total</div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Expected Temp</div>
            <div className="text-base font-bold text-[#C34133]">{optResult.expectedTempC} °C</div>
            <div className="text-[10px] text-gray-500">HW Error: {optResult.expectedErrorRatePercent}%</div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Expected Profit</div>
            <div className="text-base font-bold text-[#66FCF1]">${optResult.expectedDailyProfitUSD}</div>
            <div className="text-[10px] text-gray-500">Per Day</div>
          </div>
        </div>
      </div>

      {/* Diminishing Returns Sweep Chart */}
      <div className="space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-200 font-semibold uppercase tracking-wider text-[11px]">
            Diminishing Returns Curve: Hashrate & Profit vs. Operating Frequency
          </span>
          <span className="text-[#45A29E] text-[10px] uppercase">Notice profit peaking before maximum frequency!</span>
        </div>

        <div className="h-64 w-full bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833] text-xs">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sweepData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
              <XAxis dataKey="freqMHz" stroke="#45A29E" unit=" MHz" />
              <YAxis yAxisId="left" stroke="#66FCF1" orientation="left" unit=" TH/s" />
              <YAxis yAxisId="right" stroke="#45A29E" orientation="right" unit=" $" />
              <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="hashrateTH" name="Hashrate (TH/s)" stroke="#66FCF1" strokeWidth={2} dot={{ r: 3 }} />
              <Line yAxisId="right" type="monotone" dataKey="netProfitUSD" name="Net Profit ($/day)" stroke="#45A29E" strokeWidth={2.5} dot={{ r: 4 }} />
              <Line yAxisId="left" type="monotone" dataKey="efficiencyJTH" name="Efficiency (J/TH)" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Interactive Frequency Slider Simulator */}
      <div className="bg-[#0B0C10] border border-[#1F2833] p-4 rounded-xl space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-slate-200 font-semibold">
            <Sliders className="w-4 h-4 text-[#66FCF1]" />
            <span className="uppercase text-[11px] tracking-wider">Interactive Frequency Tuning Sandbox</span>
          </div>
          <span className="text-[#66FCF1] font-bold text-sm">{freqSweepMHz} MHz</span>
        </div>

        <input
          id="freq-sweep-slider"
          type="range"
          min={spec.minFreqMHz}
          max={spec.maxFreqMHz}
          step={10}
          value={freqSweepMHz}
          onChange={(e) => setFreqSweepMHz(parseInt(e.target.value))}
          className="w-full accent-[#66FCF1] cursor-pointer"
        />

        {/* Breakdown of Current Simulation Point */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px] pt-1">
          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider">Power Component Breakdown:</span>
            <div className="text-slate-200 mt-1 space-y-0.5">
              <div>ASIC Silicon: {Math.round(currentPerf.asicPowerW)} W</div>
              <div>PSU Loss: {Math.round(currentPerf.psuLossW)} W</div>
              <div>Fan Power: {Math.round(currentPerf.fanPowerW)} W</div>
              <div className="font-bold text-[#66FCF1] border-t border-[#1F2833] pt-0.5">Total: {Math.round(currentPerf.totalPowerW)} W</div>
            </div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider">Thermal & Error State:</span>
            <div className="text-slate-200 mt-1 space-y-0.5">
              <div>ASIC Die: {currentPerf.asicTempC.toFixed(1)} °C</div>
              <div>PCB Sensor: {currentPerf.pcbTempC.toFixed(1)} °C</div>
              <div>Thermal Margin: {currentPerf.thermalMarginC.toFixed(1)} °C</div>
              <div className="font-bold text-[#C34133] border-t border-[#1F2833] pt-0.5">HW Error Rate: {(currentPerf.hardwareErrorRate * 100).toFixed(3)}%</div>
            </div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider">Efficiency & Yield:</span>
            <div className="text-slate-200 mt-1 space-y-0.5">
              <div>Effective Hash: {currentPerf.effectiveHashrateTH.toFixed(2)} TH/s</div>
              <div>Efficiency: {currentPerf.efficiencyJTH.toFixed(2)} J/TH</div>
              <div>Density: {currentPerf.thPerKW.toFixed(2)} TH/kW</div>
              <div className="font-bold text-[#66FCF1] border-t border-[#1F2833] pt-0.5">Rejects: {currentPerf.rejectRatePercent.toFixed(2)}%</div>
            </div>
          </div>

          <div className="bg-[#1F2833]/30 p-2.5 rounded-lg border border-[#1F2833]">
            <span className="text-[#45A29E] text-[10px] uppercase tracking-wider">Financial Performance:</span>
            <div className="text-slate-200 mt-1 space-y-0.5">
              <div>Revenue: ${currentPerf.dailyRevenueUSD.toFixed(2)}/day</div>
              <div>Power Cost: ${currentPerf.dailyElectricityCostUSD.toFixed(2)}/day</div>
              <div className="font-bold text-[#66FCF1] border-t border-[#1F2833] pt-0.5">Net Profit: ${currentPerf.dailyNetProfitUSD.toFixed(2)}/day</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
