import React from 'react';
import { Cpu, Zap, Thermometer, DollarSign, Activity, ShieldCheck, AlertTriangle, RefreshCw } from 'lucide-react';
import { OperatingProfile } from '../types/mining';

interface HeaderNavProps {
  activeProfile: OperatingProfile;
  onProfileChange: (profile: OperatingProfile) => void;
  fleetSize: number;
  onFleetSizeChange: (size: number) => void;
  ambientTempC: number;
  onTempChange: (temp: number) => void;
  electricityRateKWh: number;
  onRateChange: (rate: number) => void;
  btcPriceUSD: number;
  onBtcPriceChange: (price: number) => void;
  networkDifficulty: number;
  onDifficultyChange: (diff: number) => void;
  watchdogStatus: 'HEALTHY' | 'WARNING' | 'TEMPERATURE_TRIP' | 'MANUAL_OVERRIDE';
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeProfile,
  onProfileChange,
  fleetSize,
  onFleetSizeChange,
  ambientTempC,
  onTempChange,
  electricityRateKWh,
  onRateChange,
  btcPriceUSD,
  onBtcPriceChange,
  networkDifficulty,
  onDifficultyChange,
  watchdogStatus,
  onRefresh,
  isRefreshing,
}) => {
  const profiles: { key: OperatingProfile; label: string; desc: string }[] = [
    { key: 'EFFICIENCY', label: 'EFFICIENCY', desc: 'Minimises J/TH' },
    { key: 'BALANCED', label: 'BALANCED', desc: 'Optimal ROI & Risk' },
    { key: 'HASHRATE', label: 'HASHRATE', desc: 'Max TH/s Output' },
    { key: 'PROFIT', label: 'PROFIT', desc: 'Max Net Daily Revenue' },
    { key: 'LONGEVITY', label: 'LONGEVITY', desc: 'Low Thermal Stress' },
  ];

  const fleetSizes = [1, 10, 100, 1000, 10000];

  return (
    <header id="main-header" className="bg-[#0B0C10] border-b border-[#1F2833] text-[#C5C6C7] p-4 sticky top-0 z-50 shadow-2xl">
      <div className="max-w-7xl mx-auto space-y-3">
        {/* Top Row: Title, Watchdog, Fleet Scale & Refresh */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-[#66FCF1]/10 border border-[#66FCF1]/40 flex items-center justify-center rounded-lg shadow-[0_0_12px_rgba(102,252,241,0.15)]">
              <Cpu className="w-5 h-5 text-[#66FCF1] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-white uppercase">
                  HashOptima <span className="text-xs font-mono text-[#66FCF1] opacity-80">v4.2.0-RUST_ENGINE</span>
                </h1>
              </div>
              <p className="text-[11px] font-mono text-[#45A29E] uppercase tracking-wider">
                ASIC Fleet Telemetry & Performance Optimisation Platform
              </p>
            </div>
          </div>

          {/* Watchdog Status Badge */}
          <div className="flex items-center space-x-3">
            <div
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-mono font-medium tracking-wide ${
                watchdogStatus === 'HEALTHY'
                  ? 'bg-[#45A29E]/10 text-[#66FCF1] border-[#45A29E]/30'
                  : watchdogStatus === 'TEMPERATURE_TRIP'
                  ? 'bg-[#C34133]/20 text-[#C34133] border-[#C34133]/60 animate-pulse'
                  : 'bg-amber-950/60 text-amber-400 border-amber-800'
              }`}
            >
              {watchdogStatus === 'HEALTHY' ? (
                <ShieldCheck className="w-4 h-4 text-[#66FCF1]" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-[#C34133]" />
              )}
              <span className="uppercase text-[11px]">STATUS: {watchdogStatus}</span>
            </div>

            {/* Fleet Scale Buttons */}
            <div className="flex items-center bg-[#0B0C10] p-1 rounded-lg border border-[#1F2833]">
              <span className="text-[10px] text-[#45A29E] uppercase tracking-wider px-2 font-mono">Fleet:</span>
              {fleetSizes.map((size) => (
                <button
                  key={size}
                  id={`fleet-size-btn-${size}`}
                  onClick={() => onFleetSizeChange(size)}
                  className={`px-2.5 py-1 text-xs rounded font-mono transition-all ${
                    fleetSize === size
                      ? 'bg-[#66FCF1] text-[#0B0C10] font-bold shadow-[0_0_10px_rgba(102,252,241,0.4)]'
                      : 'text-[#45A29E] hover:text-[#66FCF1] hover:bg-[#1F2833]/50'
                  }`}
                >
                  {size >= 1000 ? `${size / 1000}k` : size}
                </button>
              ))}
            </div>

            <button
              id="refresh-telemetry-btn"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="flex items-center space-x-1.5 bg-[#1F2833]/60 hover:bg-[#1F2833] text-[#66FCF1] px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider border border-[#45A29E]/30 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>Sync</span>
            </button>
          </div>
        </div>

        {/* Middle Row: Operating Profile Selector */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1">
          <span className="text-[10px] text-[#45A29E] font-mono uppercase tracking-widest pr-2">Profile:</span>
          {profiles.map((p) => (
            <button
              key={p.key}
              id={`profile-btn-${p.key}`}
              onClick={() => onProfileChange(p.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono flex flex-col items-start transition-all border ${
                activeProfile === p.key
                  ? 'bg-[#66FCF1]/10 text-[#66FCF1] border-[#66FCF1] shadow-[0_0_12px_rgba(102,252,241,0.2)]'
                  : 'bg-[#1F2833]/30 text-gray-400 border-[#1F2833] hover:border-[#45A29E]/40 hover:text-[#C5C6C7]'
              }`}
            >
              <span className="leading-tight uppercase tracking-wider">{p.label}</span>
              <span className={`text-[10px] ${activeProfile === p.key ? 'text-[#66FCF1]/80' : 'text-[#45A29E]/70'}`}>
                {p.desc}
              </span>
            </button>
          ))}
        </div>

        {/* Bottom Row: Environment Parameter Inputs Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-[#0B0C10] p-2.5 rounded-xl border border-[#1F2833] text-xs font-mono">
          <div className="flex items-center space-x-2">
            <Thermometer className="w-4 h-4 text-[#66FCF1] shrink-0" />
            <span className="text-[10px] uppercase text-[#45A29E] tracking-wider">Ambient:</span>
            <input
              id="input-ambient-temp"
              type="number"
              step="0.5"
              value={ambientTempC}
              onChange={(e) => onTempChange(parseFloat(e.target.value) || 25)}
              className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-white w-16 text-right focus:border-[#66FCF1] outline-none"
            />
            <span className="text-gray-400">°C</span>
          </div>

          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-[#66FCF1] shrink-0" />
            <span className="text-[10px] uppercase text-[#45A29E] tracking-wider">Power:</span>
            <span className="text-gray-400">$</span>
            <input
              id="input-electricity-rate"
              type="number"
              step="0.005"
              value={electricityRateKWh}
              onChange={(e) => onRateChange(parseFloat(e.target.value) || 0.05)}
              className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-white w-20 text-right focus:border-[#66FCF1] outline-none"
            />
            <span className="text-gray-400">/kWh</span>
          </div>

          <div className="flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-[#66FCF1] shrink-0" />
            <span className="text-[10px] uppercase text-[#45A29E] tracking-wider">BTC Price:</span>
            <span className="text-gray-400">$</span>
            <input
              id="input-btc-price"
              type="number"
              step="500"
              value={btcPriceUSD}
              onChange={(e) => onBtcPriceChange(parseFloat(e.target.value) || 90000)}
              className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-white w-24 text-right focus:border-[#66FCF1] outline-none"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-[#66FCF1] shrink-0" />
            <span className="text-[10px] uppercase text-[#45A29E] tracking-wider">Diff:</span>
            <input
              id="input-network-difficulty"
              type="number"
              step="0.5"
              value={networkDifficulty}
              onChange={(e) => onDifficultyChange(parseFloat(e.target.value) || 85)}
              className="bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-0.5 text-white w-20 text-right focus:border-[#66FCF1] outline-none"
            />
            <span className="text-gray-400">T</span>
          </div>
        </div>
      </div>
    </header>
  );
};
