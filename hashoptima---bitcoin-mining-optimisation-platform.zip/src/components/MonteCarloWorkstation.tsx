import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { Play, Activity, TrendingUp, ShieldAlert, BarChart2, Zap, RefreshCw } from 'lucide-react';
import { MonteCarloResult } from '../types/mining';

interface MonteCarloWorkstationProps {
  basePowerKW: number;
  baseHashrateTH: number;
  btcPriceUSD: number;
  electricityRateKWh: number;
}

export const MonteCarloWorkstation: React.FC<MonteCarloWorkstationProps> = ({
  basePowerKW,
  baseHashrateTH,
  btcPriceUSD,
  electricityRateKWh,
}) => {
  const [simCount, setSimCount] = useState<number>(10000);
  const [horizonDays, setHorizonDays] = useState<number>(90);
  const [btcVol, setBtcVol] = useState<number>(45);
  const [elecVol, setElecVol] = useState<number>(20);
  const [tempAnomaly, setTempAnomaly] = useState<number>(3);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [result, setResult] = useState<MonteCarloResult | null>(null);

  const runSimulation = async (count: number = simCount) => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/monte-carlo/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          simulationsCount: count,
          timeHorizonDays: horizonDays,
          btcPriceVolatilityPercent: btcVol,
          electricityRateVolPercent: elecVol,
          temperatureAnomalyC: tempAnomaly,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.result);
      }
    } catch (e) {
      console.error('Monte Carlo Simulation failed:', e);
    } finally {
      setIsSimulating(false);
    }
  };

  useEffect(() => {
    runSimulation(10000);
  }, [basePowerKW, baseHashrateTH, btcPriceUSD, electricityRateKWh]);

  return (
    <section id="monte-carlo-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">R Quantitative Monte Carlo Stochastic Workstation</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            Joint Uncertainty Engine (BTC Price GBM, Difficulty Shocks, Thermal Anomalies, Electricity Volatility)
          </p>
        </div>

        {/* Simulation Execution Buttons */}
        <div className="flex items-center space-x-2">
          <button
            id="run-mc-10k-btn"
            onClick={() => { setSimCount(10000); runSimulation(10000); }}
            disabled={isSimulating}
            className="flex items-center space-x-1.5 bg-[#45A29E]/20 text-[#66FCF1] border border-[#45A29E]/40 hover:bg-[#45A29E]/30 px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition shadow"
          >
            <Play className="w-3.5 h-3.5 fill-current text-[#66FCF1]" />
            <span>10,000 Runs</span>
          </button>

          <button
            id="run-mc-100k-btn"
            onClick={() => { setSimCount(100000); runSimulation(100000); }}
            disabled={isSimulating}
            className="flex items-center space-x-1.5 bg-[#66FCF1] text-[#0B0C10] hover:bg-[#45A29E] px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition shadow-[0_0_10px_rgba(102,252,241,0.4)]"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>100,000 Runs</span>
          </button>
        </div>
      </div>

      {/* Control Inputs Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833] font-mono text-xs">
        <div>
          <span className="text-[10px] text-[#45A29E] uppercase tracking-wider">Time Horizon:</span>
          <select
            id="mc-horizon-select"
            value={horizonDays}
            onChange={(e) => setHorizonDays(parseInt(e.target.value))}
            className="w-full mt-1 bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-1 text-white outline-none focus:border-[#66FCF1]"
          >
            <option value={30}>30 Days</option>
            <option value={90}>90 Days</option>
            <option value={180}>180 Days</option>
            <option value={365}>365 Days</option>
          </select>
        </div>

        <div>
          <span className="text-[10px] text-[#45A29E] uppercase tracking-wider">BTC Volatility (Annual %):</span>
          <input
            id="mc-btc-vol-input"
            type="number"
            value={btcVol}
            onChange={(e) => setBtcVol(parseInt(e.target.value) || 40)}
            className="w-full mt-1 bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-1 text-white outline-none focus:border-[#66FCF1]"
          />
        </div>

        <div>
          <span className="text-[10px] text-[#45A29E] uppercase tracking-wider">Elec Volatility (%):</span>
          <input
            id="mc-elec-vol-input"
            type="number"
            value={elecVol}
            onChange={(e) => setElecVol(parseInt(e.target.value) || 20)}
            className="w-full mt-1 bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-1 text-white outline-none focus:border-[#66FCF1]"
          />
        </div>

        <div>
          <span className="text-[10px] text-[#45A29E] uppercase tracking-wider">Temp Anomaly (°C):</span>
          <input
            id="mc-temp-anomaly-input"
            type="number"
            value={tempAnomaly}
            onChange={(e) => setTempAnomaly(parseInt(e.target.value) || 0)}
            className="w-full mt-1 bg-[#1F2833]/60 border border-[#45A29E]/30 rounded px-2 py-1 text-white outline-none focus:border-[#66FCF1]"
          />
        </div>
      </div>

      {/* Result Metrics Cards */}
      {result && (
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">P10 (Down-side) Profit</div>
            <div className="text-base font-bold text-[#C34133]">${result.p10NetProfitUSD.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500">10th Percentile</div>
          </div>

          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">P50 (Median) Profit</div>
            <div className="text-base font-bold text-[#45A29E]">${result.p50NetProfitUSD.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500">Median Expected</div>
          </div>

          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">P90 (Up-side) Profit</div>
            <div className="text-base font-bold text-[#66FCF1]">${result.p90NetProfitUSD.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500">90th Percentile</div>
          </div>

          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Mean & Std Dev</div>
            <div className="text-base font-bold text-white">${result.meanNetProfitUSD.toLocaleString()}</div>
            <div className="text-[10px] text-gray-500">± ${result.stdDevNetProfitUSD.toLocaleString()}</div>
          </div>

          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Sharpe Ratio</div>
            <div className="text-base font-bold text-[#66FCF1]">{result.sharpeRatio}</div>
            <div className="text-[10px] text-gray-500">Risk-Adjusted Return</div>
          </div>

          <div className="bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833]">
            <div className="text-[10px] text-[#45A29E] uppercase tracking-wider">Probability of Loss</div>
            <div className={`text-base font-bold ${result.probabilityOfLossPercent > 10 ? 'text-[#C34133]' : 'text-[#66FCF1]'}`}>
              {result.probabilityOfLossPercent}%
            </div>
            <div className="text-[10px] text-gray-500">{result.simulationsCount.toLocaleString()} Runs</div>
          </div>
        </div>
      )}

      {/* Two Column Monte Carlo Charts */}
      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
          {/* Histogram Chart */}
          <div className="bg-[#0B0C10] p-4 rounded-xl border border-[#1F2833] space-y-2">
            <div className="text-xs text-slate-200 font-semibold uppercase tracking-wider text-[11px]">
              Net Profit Probability Distribution ({horizonDays} Days)
            </div>
            <div className="h-56 w-full text-xs">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={result.profitDistribution} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                  <XAxis dataKey="profitBinUSD" stroke="#45A29E" tickFormatter={(v) => `$${Math.round(v / 1000)}k`} />
                  <YAxis stroke="#45A29E" />
                  <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                  <Bar dataKey="frequency" fill="#66FCF1" name="Simulations Frequency" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Time Series Fan Chart */}
          <div className="bg-[#0B0C10] p-4 rounded-xl border border-[#1F2833] space-y-2">
            <div className="text-xs text-slate-200 font-semibold uppercase tracking-wider text-[11px]">
              Stochastic Profit Trajectory (P10 / P50 / P90 Fan Chart)
            </div>
            <div className="h-56 w-full text-xs">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={result.timeSeriesPercentiles} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                  <XAxis dataKey="day" stroke="#45A29E" unit="d" />
                  <YAxis stroke="#45A29E" tickFormatter={(v) => `$${Math.round(v / 1000)}k`} />
                  <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                  <Legend />
                  <Line type="monotone" dataKey="p90" name="P90 (Up-side)" stroke="#66FCF1" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="p50" name="P50 (Median)" stroke="#45A29E" strokeWidth={2.5} dot={false} />
                  <Line type="monotone" dataKey="p10" name="P10 (Down-side)" stroke="#C34133" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
