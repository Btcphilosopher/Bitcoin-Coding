import React from 'react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, Tooltip, CartesianGrid, ZAxis } from 'recharts';
import { LayoutGrid, Cpu, Zap, Thermometer, DollarSign, Activity } from 'lucide-react';
import { FleetSummary, HardwareModel } from '../types/mining';
import { HARDWARE_SPECS } from '../engine/hardware';
import { RustPerformanceEngine } from '../engine/rustEngine';

interface RShinyDashboardProps {
  summary: FleetSummary;
  btcPriceUSD: number;
  electricityRateKWh: number;
  networkDifficulty: number;
}

export const RShinyDashboard: React.FC<RShinyDashboardProps> = ({
  summary,
  btcPriceUSD,
  electricityRateKWh,
  networkDifficulty,
}) => {
  // Generate multi-dimensional scatter datasets for the 6 requested R Shiny charts
  const samplePointsCount = 20;

  // 1. Hashrate vs Power
  const hashVsPowerData = [];
  for (let i = 0; i < samplePointsCount; i++) {
    const f = 500 + i * 25;
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: f,
      voltageV: 11.5 + i * 0.12,
      ambientTempC: 25,
      fanSpeedPercent: 75,
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });
    hashVsPowerData.push({ powerW: Math.round(perf.totalPowerW), hashrateTH: Number(perf.effectiveHashrateTH.toFixed(1)) });
  }

  // 2. Hashrate vs Temperature
  const hashVsTempData = [];
  for (let temp = 15; temp <= 45; temp += 2) {
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: 820,
      voltageV: 12.8,
      ambientTempC: temp,
      fanSpeedPercent: Math.min(100, 50 + temp * 1.2),
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });
    hashVsTempData.push({ asicTempC: Number(perf.asicTempC.toFixed(1)), hashrateTH: Number(perf.effectiveHashrateTH.toFixed(1)) });
  }

  // 3. Hashrate vs Frequency
  const hashVsFreqData = [];
  for (let f = 500; f <= 1000; f += 30) {
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: f,
      voltageV: 11.5 + (f - 500) * 0.005,
      ambientTempC: 25,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });
    hashVsFreqData.push({ freqMHz: f, hashrateTH: Number(perf.effectiveHashrateTH.toFixed(1)) });
  }

  // 4. Profit vs Electricity Price
  const profitVsElecData = [];
  for (let rate = 0.02; rate <= 0.12; rate += 0.008) {
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: 820,
      voltageV: 12.8,
      ambientTempC: 25,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD,
      electricityRateKWh: rate,
      networkDifficulty,
    });
    profitVsElecData.push({ elecRateKWh: Number(rate.toFixed(3)), profitUSD: Number(perf.dailyNetProfitUSD.toFixed(2)) });
  }

  // 5. Profit vs BTC Price
  const profitVsBtcData = [];
  for (let price = 50000; price <= 130000; price += 5000) {
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: 820,
      voltageV: 12.8,
      ambientTempC: 25,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD: price,
      electricityRateKWh,
      networkDifficulty,
    });
    profitVsBtcData.push({ btcPriceUSD: price, profitUSD: Number(perf.dailyNetProfitUSD.toFixed(2)) });
  }

  // 6. Profit vs Difficulty
  const profitVsDiffData = [];
  for (let diff = 60; diff <= 120; diff += 4) {
    const perf = RustPerformanceEngine.calculatePerformance({
      model: 'ANTMINER_S21',
      frequencyMHz: 820,
      voltageV: 12.8,
      ambientTempC: 25,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 100,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty: diff,
    });
    profitVsDiffData.push({ difficultyT: diff, profitUSD: Number(perf.dailyNetProfitUSD.toFixed(2)) });
  }

  return (
    <section id="r-shiny-dashboard-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <LayoutGrid className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">R Shiny Statistical Workstation Dashboard</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            6-Panel Response Surface & Scatter Matrix Analytics
          </p>
        </div>

        <span className="text-[10px] uppercase tracking-wider font-mono bg-[#45A29E]/20 text-[#66FCF1] px-3 py-1 rounded-lg border border-[#45A29E]/40 font-bold">
          R Shiny Rendered Workstation Mode
        </span>
      </div>

      {/* 2x3 Grid of R Shiny Analytical Plots */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        {/* 1. HASHRATE vs POWER */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">HASHRATE vs POWER</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="powerW" stroke="#45A29E" name="Power (W)" unit="W" />
                <YAxis dataKey="hashrateTH" stroke="#66FCF1" name="Hashrate (TH/s)" unit="TH" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={hashVsPowerData} fill="#66FCF1" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 2. HASHRATE vs TEMPERATURE */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">HASHRATE vs TEMPERATURE</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="asicTempC" stroke="#45A29E" name="ASIC Temp (°C)" unit="°C" />
                <YAxis dataKey="hashrateTH" stroke="#C34133" name="Hashrate (TH/s)" unit="TH" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={hashVsTempData} fill="#C34133" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 3. HASHRATE vs FREQUENCY */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">HASHRATE vs FREQUENCY</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="freqMHz" stroke="#45A29E" name="Freq (MHz)" unit="MHz" />
                <YAxis dataKey="hashrateTH" stroke="#38bdf8" name="Hashrate (TH/s)" unit="TH" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={hashVsFreqData} fill="#38bdf8" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 4. PROFIT vs ELECTRICITY PRICE */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">PROFIT vs ELECTRICITY PRICE</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="elecRateKWh" stroke="#45A29E" name="Tariff ($/kWh)" unit="$" />
                <YAxis dataKey="profitUSD" stroke="#66FCF1" name="Profit ($/day)" unit="$" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={profitVsElecData} fill="#66FCF1" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 5. PROFIT vs BTC PRICE */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">PROFIT vs BTC PRICE</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="btcPriceUSD" stroke="#45A29E" name="BTC Price ($)" tickFormatter={(v) => `$${v/1000}k`} />
                <YAxis dataKey="profitUSD" stroke="#66FCF1" name="Profit ($/day)" unit="$" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={profitVsBtcData} fill="#66FCF1" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 6. PROFIT vs DIFFICULTY */}
        <div className="bg-[#0B0C10] p-3.5 rounded-xl border border-[#1F2833] space-y-2">
          <div className="text-slate-200 font-semibold text-[11px] uppercase tracking-wider">PROFIT vs DIFFICULTY</div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
                <XAxis dataKey="difficultyT" stroke="#45A29E" name="Difficulty (T)" unit="T" />
                <YAxis dataKey="profitUSD" stroke="#45A29E" name="Profit ($/day)" unit="$" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
                <Scatter data={profitVsDiffData} fill="#45A29E" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </section>
  );
};
