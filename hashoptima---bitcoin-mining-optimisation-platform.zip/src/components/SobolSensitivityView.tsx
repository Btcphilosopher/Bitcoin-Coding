import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, Cell } from 'recharts';
import { BarChart3, TrendingUp, HelpCircle, Layers } from 'lucide-react';
import { SensitivityMetric } from '../types/mining';

export const SobolSensitivityView: React.FC = () => {
  const [metrics, setMetrics] = useState<SensitivityMetric[]>([]);

  useEffect(() => {
    fetch('/api/sensitivity/metrics')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setMetrics(data.metrics);
      })
      .catch((err) => console.error('Sensitivity fetch error:', err));
  }, []);

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'MARKET': return '#66FCF1'; // Bright Cyan
      case 'OPERATIONAL': return '#45A29E'; // Muted Teal
      case 'HARDWARE': return '#38bdf8'; // Sky
      case 'ENVIRONMENT': return '#C34133'; // Red
      default: return '#C5C6C7';
    }
  };

  return (
    <section id="sensitivity-view-section" className="bg-[#1F2833]/40 border border-[#1F2833] rounded-xl p-5 space-y-5 text-[#C5C6C7] shadow-2xl font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1F2833] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-[#66FCF1]" />
            <h2 className="text-lg font-bold text-white uppercase tracking-tight font-mono">R Global Sensitivity Analysis & Sobol Variance Decomposition</h2>
          </div>
          <p className="text-[11px] text-[#45A29E] font-mono uppercase tracking-wider">
            First-Order (S_i) & Total Effect (S_Ti) Indices with Pearson/Spearman Rank Correlations
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono uppercase tracking-wider text-[10px]">
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#66FCF1]"></span><span>Market</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#45A29E]"></span><span>Operational</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span><span>Hardware</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-[#C34133]"></span><span>Environment</span></span>
        </div>
      </div>

      {/* Variance Decomposition Bar Chart */}
      <div className="space-y-3 font-mono">
        <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider text-[11px]">
          Global Variance Contribution Percentage (%) to Net Profit Volatility
        </div>

        <div className="h-64 w-full bg-[#0B0C10] p-3 rounded-xl border border-[#1F2833] text-xs">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={metrics} layout="vertical" margin={{ top: 10, right: 20, left: 120, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2833" />
              <XAxis type="number" stroke="#45A29E" unit="%" />
              <YAxis type="category" dataKey="variableName" stroke="#C5C6C7" width={110} />
              <Tooltip contentStyle={{ backgroundColor: '#0B0C10', borderColor: '#1F2833', borderRadius: '8px', color: '#66FCF1' }} />
              <Bar dataKey="varianceContributionPercent" name="Variance Contribution (%)">
                {metrics.map((m, idx) => (
                  <Cell key={`cell-${idx}`} fill={getCategoryColor(m.category)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Metrics Table */}
      <div className="overflow-x-auto rounded-xl border border-[#1F2833] bg-[#0B0C10] font-mono text-xs">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#1F2833]/40 border-b border-[#1F2833] text-[#45A29E] text-[10px] uppercase tracking-wider">
              <th className="p-2.5">RANK</th>
              <th className="p-2.5">VARIABLE</th>
              <th className="p-2.5">CATEGORY</th>
              <th className="p-2.5">PEARSON (r)</th>
              <th className="p-2.5">SPEARMAN (ρ)</th>
              <th className="p-2.5">SOBOL 1ST (S_i)</th>
              <th className="p-2.5">SOBOL TOTAL (S_Ti)</th>
              <th className="p-2.5">VARIANCE CONTRIB (%)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1F2833]/60">
            {metrics.map((m) => (
              <tr key={m.variableName} className="hover:bg-[#1F2833]/20 transition">
                <td className="p-2.5 font-bold text-[#66FCF1]">#{m.rank}</td>
                <td className="p-2.5 font-bold text-white">{m.variableName}</td>
                <td className="p-2.5">
                  <span
                    className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: `${getCategoryColor(m.category)}20`,
                      color: getCategoryColor(m.category),
                      border: `1px solid ${getCategoryColor(m.category)}60`,
                    }}
                  >
                    {m.category}
                  </span>
                </td>
                <td className={`p-2.5 ${m.pearsonCorrelation >= 0 ? 'text-[#66FCF1]' : 'text-[#C34133]'}`}>
                  {m.pearsonCorrelation > 0 ? `+${m.pearsonCorrelation}` : m.pearsonCorrelation}
                </td>
                <td className={`p-2.5 ${m.spearmanCorrelation >= 0 ? 'text-[#66FCF1]' : 'text-[#C34133]'}`}>
                  {m.spearmanCorrelation > 0 ? `+${m.spearmanCorrelation}` : m.spearmanCorrelation}
                </td>
                <td className="p-2.5 text-gray-300">{m.sobolFirstOrderIndex}</td>
                <td className="p-2.5 text-gray-300">{m.sobolTotalEffectIndex}</td>
                <td className="p-2.5 font-bold text-[#66FCF1]">{m.varianceContributionPercent}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};
