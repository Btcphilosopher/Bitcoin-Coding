import { AdaptiveControlStep, HardwareModel } from '../types/mining';
import { HARDWARE_SPECS } from './hardware';
import { RustPerformanceEngine } from './rustEngine';

export interface WatchdogState {
  status: 'HEALTHY' | 'WARNING' | 'COMMUNICATION_LOSS' | 'TEMPERATURE_TRIP' | 'MANUAL_OVERRIDE';
  lastHeartbeatTime: string;
  activeMinersCount: number;
  commLossFallbackActive: boolean;
  tempProtectionTripped: boolean;
  rollbackHistory: AdaptiveControlStep[];
}

export class SafeAdaptiveControlEngine {
  private static auditLog: AdaptiveControlStep[] = [];
  private static watchdog: WatchdogState = {
    status: 'HEALTHY',
    lastHeartbeatTime: new Date().toISOString(),
    activeMinersCount: 100,
    commLossFallbackActive: false,
    tempProtectionTripped: false,
    rollbackHistory: [],
  };

  /**
   * Executes a step in the Safe Adaptive Control loop.
   */
  public static executeControlCycle(
    minerId: string,
    model: HardwareModel,
    currentFreqMHz: number,
    currentVoltageV: number,
    deltaFreqMHz: number, // Small change step (e.g. +10 MHz or -10 MHz)
    ambientTempC: number,
    electricityRateKWh: number,
    btcPriceUSD: number,
    networkDifficulty: number
  ): {
    steps: AdaptiveControlStep[];
    watchdogStatus: WatchdogState;
    newFreqMHz: number;
  } {
    const now = new Date().toISOString();
    const stepId = `STEP_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

    // 1. OBSERVE PRE-CHANGE
    const spec = HARDWARE_SPECS[model];
    const prePerf = RustPerformanceEngine.calculatePerformance({
      model,
      frequencyMHz: currentFreqMHz,
      voltageV: currentVoltageV,
      ambientTempC,
      fanSpeedPercent: 80,
      siliconQualityScore: 1.0,
      ageDays: 180,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });

    const proposedFreq = Math.max(spec.minFreqMHz, Math.min(spec.maxFreqMHz, currentFreqMHz + deltaFreqMHz));

    // 2. SIMULATE & PREDICT
    const predPerf = RustPerformanceEngine.calculatePerformance({
      model,
      frequencyMHz: proposedFreq,
      voltageV: currentVoltageV,
      ambientTempC,
      fanSpeedPercent: 85,
      siliconQualityScore: 1.0,
      ageDays: 180,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });

    const stepEntry: AdaptiveControlStep = {
      stepId,
      timestamp: now,
      phase: 'OBSERVE',
      minerId,
      parameterName: 'frequency_mhz',
      previousValue: currentFreqMHz,
      proposedValue: proposedFreq,
      predictedHashrateTH: predPerf.effectiveHashrateTH,
      predictedTempC: predPerf.asicTempC,
      predictedProfitUSD: predPerf.dailyNetProfitUSD,
      decision: 'PENDING',
      reason: 'Initiated small step frequency tuning',
    };

    // 3. SAFETY WATCHDOG CHECK
    if (predPerf.asicTempC > spec.maxTempASICC - 2) {
      stepEntry.phase = 'REVERT';
      stepEntry.decision = 'SAFETY_TRIP';
      stepEntry.reason = `Predicted temperature ${predPerf.asicTempC.toFixed(1)}°C exceeds thermal safety threshold ${spec.maxTempASICC - 2}°C. Operation Aborted.`;
      this.watchdog.status = 'TEMPERATURE_TRIP';
      this.watchdog.tempProtectionTripped = true;
      this.auditLog.unshift(stepEntry);

      return {
        steps: [stepEntry],
        watchdogStatus: { ...this.watchdog },
        newFreqMHz: currentFreqMHz, // Keep old freq
      };
    }

    // 4. MAKE SMALL CHANGE & OBSERVE POST-CHANGE
    // Simulated small physical lag measurement
    const postHashrateNoise = (Math.random() - 0.5) * 1.2;
    const postTempNoise = (Math.random() - 0.5) * 0.5;

    const actualHashrateTH = predPerf.effectiveHashrateTH + postHashrateNoise;
    const actualTempC = predPerf.asicTempC + postTempNoise;
    const actualErrorRate = predPerf.hardwareErrorRate;

    stepEntry.actualHashrateTH = Number(actualHashrateTH.toFixed(2));
    stepEntry.actualTempC = Number(actualTempC.toFixed(1));
    stepEntry.actualErrorRate = Number((actualErrorRate * 100).toFixed(3));

    // 5. COMPARE & ACCEPT / REVERT
    const profitDelta = predPerf.dailyNetProfitUSD - prePerf.dailyNetProfitUSD;
    const isPerformanceImproved = actualHashrateTH > prePerf.effectiveHashrateTH && actualErrorRate < 0.02;

    if (isPerformanceImproved && profitDelta >= -0.05) {
      stepEntry.phase = 'ACCEPT';
      stepEntry.decision = 'ACCEPTED';
      stepEntry.reason = `Confirmed sustained hashrate increase (+${(actualHashrateTH - prePerf.effectiveHashrateTH).toFixed(2)} TH/s) within thermal limits. Change committed.`;
      this.auditLog.unshift(stepEntry);

      return {
        steps: [stepEntry],
        watchdogStatus: { ...this.watchdog, status: 'HEALTHY' },
        newFreqMHz: proposedFreq,
      };
    } else {
      stepEntry.phase = 'REVERT';
      stepEntry.decision = 'REVERTED';
      stepEntry.reason = `Post-change validation failed: Diminishing returns or higher error rate detected. Rolling back frequency to ${currentFreqMHz} MHz.`;
      this.auditLog.unshift(stepEntry);
      this.watchdog.rollbackHistory.push(stepEntry);

      return {
        steps: [stepEntry],
        watchdogStatus: { ...this.watchdog },
        newFreqMHz: currentFreqMHz, // Revert
      };
    }
  }

  public static getAuditLog(): AdaptiveControlStep[] {
    return this.auditLog;
  }

  public static getWatchdogState(): WatchdogState {
    return this.watchdog;
  }

  public static triggerManualOverride(enabled: boolean) {
    this.watchdog.status = enabled ? 'MANUAL_OVERRIDE' : 'HEALTHY';
  }
}
