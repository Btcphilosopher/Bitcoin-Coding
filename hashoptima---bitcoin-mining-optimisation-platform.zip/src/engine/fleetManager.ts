import { ASICBoardTelemetry, DispatchState, FleetSummary, HardwareModel, MinerTelemetry, OperatingProfile } from '../types/mining';
import { HARDWARE_SPECS } from './hardware';
import { RustPerformanceEngine } from './rustEngine';

export class FleetManager {
  /**
   * Generates a realistic simulated fleet of miners with binning/silicon lottery variance.
   */
  public static generateFleet(
    count: number,
    profile: OperatingProfile,
    ambientTempC: number,
    electricityRateKWh: number,
    btcPriceUSD: number,
    networkDifficulty: number
  ): MinerTelemetry[] {
    const models: HardwareModel[] = [
      'ANTMINER_S21',
      'ANTMINER_S19_XP',
      'ANTMINER_S19_PRO',
      'ANTMINER_S21_HYDRO',
      'WHATSMINER_M50S',
    ];

    const fleet: MinerTelemetry[] = [];

    for (let i = 0; i < count; i++) {
      const model = models[i % models.length];
      const spec = HARDWARE_SPECS[model];

      // Silicon lottery multiplier (0.88 to 1.12)
      const siliconQualityScore = 0.88 + Math.random() * 0.24;
      const ageDays = Math.floor(Math.random() * 500);

      // Model-specific operational parameters with profile adjustment
      let freqMHz = spec.nominalFreqMHz;
      let voltV = spec.minVoltageV + (spec.maxVoltageV - spec.minVoltageV) * 0.4;

      if (profile === 'EFFICIENCY') {
        freqMHz = spec.nominalFreqMHz * 0.88;
        voltV = spec.minVoltageV * 1.02;
      } else if (profile === 'HASHRATE') {
        freqMHz = spec.maxFreqMHz * 0.95;
        voltV = spec.maxVoltageV * 0.95;
      } else if (profile === 'LONGEVITY') {
        freqMHz = spec.nominalFreqMHz * 0.82;
        voltV = spec.minVoltageV * 1.01;
      }

      // Add individual miner noise
      freqMHz += (Math.random() - 0.5) * 30;
      const fanPct = Math.min(100, Math.max(30, 75 + (ambientTempC - 20) * 1.2 + (Math.random() - 0.5) * 10));

      const perf = RustPerformanceEngine.calculatePerformance({
        model,
        frequencyMHz: freqMHz,
        voltageV: voltV,
        ambientTempC,
        fanSpeedPercent: fanPct,
        siliconQualityScore,
        ageDays,
        btcPriceUSD,
        electricityRateKWh,
        networkDifficulty,
      });

      // Individual Board Telemetry
      const boards: ASICBoardTelemetry[] = Array.from({ length: spec.hashBoardsCount }, (_, bIdx) => {
        const boardTempASIC = perf.asicTempC + (bIdx - 1) * 2.5 + (Math.random() - 0.5);
        const boardTempPCB = perf.pcbTempC + (bIdx - 1) * 2.0;
        const bStatus: 'OK' | 'WARNING' | 'ERROR' | 'DISABLED' = boardTempASIC > spec.maxTempASICC ? 'ERROR' : 'OK';

        return {
          boardId: bIdx + 1,
          status: bStatus,
          temperatureASIC: Number(boardTempASIC.toFixed(1)),
          temperaturePCB: Number(boardTempPCB.toFixed(1)),
          frequencyMHz: Math.round(freqMHz),
          voltageV: Number(voltV.toFixed(2)),
          hashrateTH: Number((perf.effectiveHashrateTH / spec.hashBoardsCount).toFixed(2)),
          hardwareErrors: Math.floor(perf.hardwareErrorRate * 1000 * (bIdx + 1)),
          chipCountActive: spec.chipsPerBoard,
          chipCountTotal: spec.chipsPerBoard,
        };
      });

      // Dispatch state based on profit
      let dispatchState: DispatchState = 'FULL_POWER';
      if (perf.dailyNetProfitUSD < 0) {
        dispatchState = perf.dailyNetProfitUSD > -1.0 ? 'REDUCED_POWER' : 'OFFLINE';
      }

      fleet.push({
        minerId: `MINER-${String(i + 1).padStart(5, '0')}`,
        ipAddress: `192.168.${Math.floor(i / 254) + 1}.${(i % 254) + 1}`,
        model,
        serialNumber: `BIT-${model.substring(0, 4)}-${100000 + i}`,
        uptimeSeconds: Math.floor(86400 * (15 + Math.random() * 45)),
        operatingMode: profile,
        dispatchState,

        instantHashrateTH: Number((perf.effectiveHashrateTH * (1 + (Math.random() - 0.5) * 0.03)).toFixed(2)),
        rolling5mHashrateTH: Number((perf.effectiveHashrateTH * (1 + (Math.random() - 0.5) * 0.015)).toFixed(2)),
        rolling15mHashrateTH: Number((perf.effectiveHashrateTH * (1 + (Math.random() - 0.5) * 0.008)).toFixed(2)),
        rolling1hHashrateTH: Number(perf.effectiveHashrateTH.toFixed(2)),
        effectiveHashrateTH: Number(perf.effectiveHashrateTH.toFixed(2)),

        asicPowerW: Math.round(perf.asicPowerW),
        psuLossW: Math.round(perf.psuLossW),
        fanPowerW: Math.round(perf.fanPowerW),
        totalPowerW: Math.round(perf.totalPowerW),
        efficiencyJTH: Number(perf.efficiencyJTH.toFixed(2)),
        thPerKW: Number(perf.thPerKW.toFixed(2)),

        ambientTempC,
        intakeTempC: Number((ambientTempC + 1.2).toFixed(1)),
        exhaustTempC: Number((perf.asicTempC - 12).toFixed(1)),
        maxASICTempC: Number(perf.asicTempC.toFixed(1)),
        maxPCBTempC: Number(perf.pcbTempC.toFixed(1)),
        fanSpeedRPM: Math.round((fanPct / 100) * spec.maxFanRPM),
        fanSpeedPercent: Math.round(fanPct),
        thermalMarginC: Number(perf.thermalMarginC.toFixed(1)),

        hardwareErrors: Math.floor(perf.hardwareErrorRate * 5000),
        hardwareErrorRate: Number(perf.hardwareErrorRate.toFixed(4)),
        acceptedShares: Math.floor(25000 * (1 - perf.hardwareErrorRate)),
        rejectedShares: Math.floor(25000 * (perf.rejectRatePercent / 100)),
        rejectRatePercent: Number(perf.rejectRatePercent.toFixed(2)),
        poolLatencyMs: Math.round(22 + Math.random() * 15),

        boards,
        ageDays,
        siliconQualityScore: Number(siliconQualityScore.toFixed(3)),
        failureRiskPercent: Number(perf.failureRiskPercent.toFixed(1)),
      });
    }

    return fleet;
  }

  /**
   * Sorts & ranks fleet by J/TH, Hashrate, Temp, Health, Revenue, Electricity cost, Failure Risk.
   */
  public static rankFleet(fleet: MinerTelemetry[], sortBy: keyof MinerTelemetry = 'efficiencyJTH'): MinerTelemetry[] {
    return [...fleet].sort((a, b) => {
      const valA = a[sortBy] as number;
      const valB = b[sortBy] as number;
      // Ascending for efficiency J/TH, error rate, failure risk; Descending for Hashrate
      if (sortBy === 'efficiencyJTH' || sortBy === 'failureRiskPercent' || sortBy === 'maxASICTempC') {
        return valA - valB;
      }
      return valB - valA;
    });
  }

  /**
   * Calculates grand fleet summary totals.
   */
  public static calculateFleetSummary(
    fleet: MinerTelemetry[],
    btcPriceUSD: number,
    networkDifficulty: number,
    electricityRateKWh: number
  ): FleetSummary {
    const totalCount = fleet.length;
    let active = 0, reduced = 0, standby = 0, offline = 0;
    let totalHash = 0, totalPowerW = 0, sumTemp = 0, sumError = 0, sumUptime = 0;

    for (const m of fleet) {
      if (m.dispatchState === 'FULL_POWER') active++;
      else if (m.dispatchState === 'REDUCED_POWER') reduced++;
      else if (m.dispatchState === 'STANDBY') standby++;
      else offline++;

      if (m.dispatchState !== 'OFFLINE') {
        totalHash += m.effectiveHashrateTH;
        totalPowerW += m.totalPowerW;
      }

      sumTemp += m.maxASICTempC;
      sumError += m.hardwareErrorRate;
      sumUptime += m.uptimeSeconds;
    }

    const facilityPowerKW = totalPowerW / 1000;
    const coolingPowerKW = facilityPowerKW * 0.08; // 8% HVAC/PUE cooling load
    const facilityOverheadKW = facilityPowerKW * 0.02; // 2% transformer/PDU load
    const grandTotalPowerKW = facilityPowerKW + coolingPowerKW + facilityOverheadKW;

    const effJTH = totalHash > 0 ? (grandTotalPowerKW * 1000) / totalHash : 0;

    // Financials
    const netHashHps = networkDifficulty * 1e12 * Math.pow(2, 32) / 600;
    const fleetHps = totalHash * 1e12;
    const share = fleetHps / netHashHps;
    const dailyBtcMined = share * 144 * 3.125 * 0.985;
    const dailyRevenueUSD = dailyBtcMined * btcPriceUSD;

    const dailyKWh = grandTotalPowerKW * 24;
    const dailyElectricityCostUSD = dailyKWh * electricityRateKWh;
    const dailyCoolingCostUSD = coolingPowerKW * 24 * electricityRateKWh;
    const dailyFacilityOverheadUSD = facilityOverheadKW * 24 * electricityRateKWh;
    const dailyNetProfitUSD = dailyRevenueUSD - dailyElectricityCostUSD;

    return {
      totalMinersCount: totalCount,
      activeCount: active,
      reducedPowerCount: reduced,
      standbyCount: standby,
      offlineCount: offline,

      totalHashrateTH: Number(totalHash.toFixed(2)),
      totalPowerKW: Number(facilityPowerKW.toFixed(1)),
      facilityOverheadKW: Number(facilityOverheadKW.toFixed(1)),
      coolingPowerKW: Number(coolingPowerKW.toFixed(1)),
      grandTotalPowerKW: Number(grandTotalPowerKW.toFixed(1)),

      effectiveEfficiencyJTH: Number(effJTH.toFixed(2)),
      averageASICTempC: Number((sumTemp / Math.max(1, totalCount)).toFixed(1)),
      averageErrorRate: Number(((sumError / Math.max(1, totalCount)) * 100).toFixed(3)),
      averageUptimePercent: 98.4,

      btcPriceUSD,
      networkDifficulty,
      networkHashrateEH: Number((netHashHps / 1e18).toFixed(2)),
      dailyBtcMined: Number(dailyBtcMined.toFixed(4)),
      dailyRevenueUSD: Number(dailyRevenueUSD.toFixed(2)),
      dailyElectricityCostUSD: Number(dailyElectricityCostUSD.toFixed(2)),
      dailyCoolingCostUSD: Number(dailyCoolingCostUSD.toFixed(2)),
      dailyFacilityOverheadUSD: Number(dailyFacilityOverheadUSD.toFixed(2)),
      dailyNetProfitUSD: Number(dailyNetProfitUSD.toFixed(2)),
      profitPerKWhUSD: dailyKWh > 0 ? Number((dailyNetProfitUSD / dailyKWh).toFixed(4)) : 0,
      profitPerTHUSD: totalHash > 0 ? Number((dailyNetProfitUSD / totalHash).toFixed(4)) : 0,
    };
  }
}
