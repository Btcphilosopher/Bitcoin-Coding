import { HardwareModel, HardwareSpec } from '../types/mining';

export const HARDWARE_SPECS: Record<HardwareModel, HardwareSpec> = {
  ANTMINER_S19_PRO: {
    model: 'ANTMINER_S19_PRO',
    displayName: 'Bitmain Antminer S19 Pro (110 TH/s)',
    nominalHashrateTH: 110,
    nominalPowerW: 3250,
    nominalEfficiencyJTH: 29.54,
    hashBoardsCount: 3,
    chipsPerBoard: 126,
    minFreqMHz: 450,
    maxFreqMHz: 750,
    nominalFreqMHz: 600,
    minVoltageV: 12.0,
    maxVoltageV: 15.0,
    maxTempASICC: 85,
    maxTempPCBC: 75,
    maxFanRPM: 6200,
    coolingType: 'AIR',
    firmwareSupport: ['Bitmain Stock', 'Braiins OS+', 'LuxOS', 'Vnish'],
  },
  ANTMINER_S19_XP: {
    model: 'ANTMINER_S19_XP',
    displayName: 'Bitmain Antminer S19 XP (141 TH/s)',
    nominalHashrateTH: 141,
    nominalPowerW: 3031,
    nominalEfficiencyJTH: 21.50,
    hashBoardsCount: 3,
    chipsPerBoard: 114,
    minFreqMHz: 500,
    maxFreqMHz: 880,
    nominalFreqMHz: 700,
    minVoltageV: 11.5,
    maxVoltageV: 14.5,
    maxTempASICC: 88,
    maxTempPCBC: 78,
    maxFanRPM: 6500,
    coolingType: 'AIR',
    firmwareSupport: ['Bitmain Stock', 'Braiins OS+', 'LuxOS'],
  },
  ANTMINER_S21: {
    model: 'ANTMINER_S21',
    displayName: 'Bitmain Antminer S21 (200 TH/s)',
    nominalHashrateTH: 200,
    nominalPowerW: 3500,
    nominalEfficiencyJTH: 17.50,
    hashBoardsCount: 3,
    chipsPerBoard: 108,
    minFreqMHz: 550,
    maxFreqMHz: 1050,
    nominalFreqMHz: 820,
    minVoltageV: 11.0,
    maxVoltageV: 14.2,
    maxTempASICC: 80,
    maxTempPCBC: 70,
    maxFanRPM: 7000,
    coolingType: 'AIR',
    firmwareSupport: ['Bitmain Stock APW121415', 'LuxOS Custom'],
  },
  ANTMINER_S21_HYDRO: {
    model: 'ANTMINER_S21_HYDRO',
    displayName: 'Bitmain Antminer S21 Hydro (335 TH/s)',
    nominalHashrateTH: 335,
    nominalPowerW: 5360,
    nominalEfficiencyJTH: 16.00,
    hashBoardsCount: 4,
    chipsPerBoard: 132,
    minFreqMHz: 600,
    maxFreqMHz: 1250,
    nominalFreqMHz: 950,
    minVoltageV: 11.0,
    maxVoltageV: 15.0,
    maxTempASICC: 75, // Hydro lower thermal trip
    maxTempPCBC: 65,
    maxFanRPM: 0, // Liquid pump cooling
    coolingType: 'HYDRO',
    firmwareSupport: ['Bitmain Hydro Special'],
  },
  WHATSMINER_M50S: {
    model: 'WHATSMINER_M50S',
    displayName: 'MicroBT Whatsminer M50S (126 TH/s)',
    nominalHashrateTH: 126,
    nominalPowerW: 3276,
    nominalEfficiencyJTH: 26.00,
    hashBoardsCount: 3,
    chipsPerBoard: 105,
    minFreqMHz: 480,
    maxFreqMHz: 800,
    nominalFreqMHz: 650,
    minVoltageV: 11.8,
    maxVoltageV: 14.8,
    maxTempASICC: 86,
    maxTempPCBC: 76,
    maxFanRPM: 6000,
    coolingType: 'AIR',
    firmwareSupport: ['Whatsminer Stock', 'Whatsminer High Power'],
  },
};

/**
 * Model-specific CGMiner / BMS API register command structure mockup.
 * Demonstrates model-specific control logic differences.
 */
export interface ModelControlPayload {
  model: HardwareModel;
  command: string;
  parameters: {
    voltage_mv?: number;
    freq_mhz?: number;
    fan_speed_pct?: number;
    power_limit_w?: number;
    temp_target_c?: number;
  };
}

export function buildModelControlPayload(
  model: HardwareModel,
  freqMHz: number,
  voltageV: number,
  fanPct: number
): ModelControlPayload {
  const spec = HARDWARE_SPECS[model];
  const safeFreq = Math.max(spec.minFreqMHz, Math.min(spec.maxFreqMHz, freqMHz));
  const safeVolts = Math.max(spec.minVoltageV, Math.min(spec.maxVoltageV, voltageV));

  switch (model) {
    case 'ANTMINER_S19_PRO':
    case 'ANTMINER_S19_XP':
      return {
        model,
        command: 'set_asic_freq_voltage',
        parameters: {
          freq_mhz: Math.round(safeFreq),
          voltage_mv: Math.round(safeVolts * 1000),
          fan_speed_pct: Math.round(fanPct),
        },
      };

    case 'ANTMINER_S21':
    case 'ANTMINER_S21_HYDRO':
      return {
        model,
        command: 'apw12_set_target_power_and_freq',
        parameters: {
          freq_mhz: Math.round(safeFreq),
          voltage_mv: Math.round(safeVolts * 1000),
          power_limit_w: Math.round((safeFreq / spec.nominalFreqMHz) * spec.nominalPowerW),
          temp_target_c: spec.maxTempASICC - 10,
        },
      };

    case 'WHATSMINER_M50S':
      return {
        model,
        command: 'btminer_set_power_mode',
        parameters: {
          freq_mhz: Math.round(safeFreq),
          voltage_mv: Math.round(safeVolts * 1000),
          fan_speed_pct: Math.round(fanPct),
        },
      };
  }
}
