import { DispatchState, DynamicHourlyTariff, FleetSummary, MinerTelemetry } from '../types/mining';

export interface EconomicsInput {
  btcPriceUSD: number;
  networkDifficulty: number; // in Trillions (e.g. 85.0)
  electricityRateKWh: number; // e.g. $0.05 / kWh
  facilityPowerKW: number;
  totalHashrateTH: number;
  coolingCoeffCOP: number; // Coefficient of performance (e.g. 4.0 for chillers/cooling towers)
  facilityOverheadRatePercent: number; // e.g. 2% PUE overhead
  hardwareDepreciationDailyUSD: number;
}

export class REconomicsEngine {
  /**
   * Calculates high-precision daily mining economics.
   */
  public static calculateDailyEconomics(input: EconomicsInput) {
    // 1. Calculate BTC Mined per Day
    // Formula: (Hashrate_TH * 1e12) / (Difficulty * 2^32 / 600) * 144 blocks * 3.125 BTC * (1 - PoolFee)
    const difficultyHps = input.networkDifficulty * 1e12 * Math.pow(2, 32) / 600;
    const fleetHps = input.totalHashrateTH * 1e12;
    const networkShare = fleetHps / difficultyHps;
    
    const blockRewardBTC = 3.125;
    const blocksPerDay = 144;
    const grossBtcDay = networkShare * blocksPerDay * blockRewardBTC;
    const netBtcDay = grossBtcDay * 0.985; // 1.5% pool fee

    // 2. Revenue Calculation
    const revenueUSD = netBtcDay * input.btcPriceUSD;

    // 3. Electricity Costs
    const miningKWhDay = input.facilityPowerKW * 24;
    const miningElectricityCostUSD = miningKWhDay * input.electricityRateKWh;

    // Cooling Cost: Cooling energy = Mining Power / COP
    const coolingKWhDay = (miningKWhDay / Math.max(1, input.coolingCoeffCOP));
    const coolingCostUSD = coolingKWhDay * input.electricityRateKWh;

    // Facility Overhead (PUE + Transformer/Distribution)
    const facilityOverheadCostUSD = miningElectricityCostUSD * (input.facilityOverheadRatePercent / 100);

    // 4. Margins & Net Profit
    const totalOpExUSD = miningElectricityCostUSD + coolingCostUSD + facilityOverheadCostUSD;
    const grossMarginUSD = revenueUSD - totalOpExUSD;
    const netProfitUSD = grossMarginUSD - input.hardwareDepreciationDailyUSD;

    // Unit Economics
    const totalKWhDay = miningKWhDay + coolingKWhDay;
    const profitPerKWhUSD = totalKWhDay > 0 ? netProfitUSD / totalKWhDay : 0;
    const profitPerTHUSD = input.totalHashrateTH > 0 ? netProfitUSD / input.totalHashrateTH : 0;

    return {
      dailyBtcMined: netBtcDay,
      dailyRevenueUSD: revenueUSD,
      dailyMiningElectricityCostUSD: miningElectricityCostUSD,
      dailyCoolingCostUSD: coolingCostUSD,
      dailyFacilityOverheadUSD: facilityOverheadCostUSD,
      dailyTotalOpExUSD: totalOpExUSD,
      dailyGrossMarginUSD: grossMarginUSD,
      dailyNetProfitUSD: netProfitUSD,
      profitPerKWhUSD,
      profitPerTHUSD,
      effectivePUE: 1 + (1 / input.coolingCoeffCOP) + (input.facilityOverheadRatePercent / 100),
    };
  }

  /**
   * Generates a 24-hour Dynamic Electricity Price Schedule with auto-dispatch decisions.
   */
  public static generateDynamicTariffDispatchSchedule(
    baseTariffKWh: number,
    basePowerKW: number,
    baseHashrateTH: number,
    btcPriceUSD: number,
    networkDifficulty: number,
    thresholdProfitMarginUSD: number = 0.05 // Min $0.05/TH profit threshold
  ): DynamicHourlyTariff[] {
    const schedule: DynamicHourlyTariff[] = [];

    // Typical diurnal electricity price curve with peak hours (14:00 - 19:00)
    const priceMultipliers = [
      0.75, 0.70, 0.65, 0.65, 0.70, 0.85, 1.10, 1.25,
      1.20, 1.15, 1.10, 1.05, 1.15, 1.35, 1.85, 2.40, // Peak 15:00-16:00
      2.10, 1.70, 1.40, 1.20, 1.05, 0.95, 0.85, 0.80
    ];

    for (let h = 0; h < 24; h++) {
      const hourlyRate = baseTariffKWh * priceMultipliers[h];

      // Calculate 1-hour economics at full power
      const econ = this.calculateDailyEconomics({
        btcPriceUSD,
        networkDifficulty,
        electricityRateKWh: hourlyRate,
        facilityPowerKW: basePowerKW,
        totalHashrateTH: baseHashrateTH,
        coolingCoeffCOP: 4.0,
        facilityOverheadRatePercent: 2.0,
        hardwareDepreciationDailyUSD: 100,
      });

      const hourlyRev = econ.dailyRevenueUSD / 24;
      const hourlyCost = econ.dailyTotalOpExUSD / 24;
      const hourlyProfit = hourlyRev - hourlyCost;
      const profitMarginPerTH = hourlyProfit / Math.max(1, baseHashrateTH);

      // Determine Dispatch State Machine
      let state: DispatchState = 'FULL_POWER';

      if (profitMarginPerTH >= thresholdProfitMarginUSD) {
        state = 'FULL_POWER';
      } else if (profitMarginPerTH >= 0) {
        state = 'REDUCED_POWER'; // Under-clock for maximum J/TH efficiency
      } else if (profitMarginPerTH >= -0.02) {
        state = 'STANDBY'; // Maintain fans for quick restart
      } else {
        state = 'OFFLINE'; // Curtail completely to prevent operating losses
      }

      schedule.push({
        hour: h,
        electricityRateKWh: Number(hourlyRate.toFixed(4)),
        expectedBtcPriceUSD: btcPriceUSD,
        expectedRevenueUSD: Number((hourlyRev).toFixed(2)),
        expectedPowerCostUSD: Number((hourlyCost).toFixed(2)),
        expectedProfitUSD: Number((hourlyProfit).toFixed(2)),
        recommendedState: state,
      });
    }

    return schedule;
  }
}
