import { MonteCarloConfig, MonteCarloResult } from '../types/mining';

export class RMonteCarloEngine {
  /**
   * Fast vectorised Monte Carlo simulation engine modeling joint stochastic paths.
   */
  public static runSimulation(
    config: MonteCarloConfig,
    basePowerKW: number,
    baseHashrateTH: number
  ): MonteCarloResult {
    const N = Math.min(100000, Math.max(1000, config.simulationsCount)); // Clamp up to 100k for fast execution
    const days = config.timeHorizonDays;

    const netProfits: number[] = new Array(N);
    const dailySeriesP10: number[] = new Array(days).fill(0);
    const dailySeriesP50: number[] = new Array(days).fill(0);
    const dailySeriesP90: number[] = new Array(days).fill(0);

    const btcDriftDay = 0.0003; // ~11% annual drift
    const btcVolDay = (config.btcPriceVolatilityPercent / 100) / Math.sqrt(365);
    const elecVol = config.electricityRateVolPercent / 100;

    // Normal RNG Box-Muller generator
    const randNorm = (): number => {
      let u = 0, v = 0;
      while (u === 0) u = Math.random();
      while (v === 0) v = Math.random();
      return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    };

    let totalProfitsSum = 0;
    let totalProfitsSqSum = 0;
    let lossCount = 0;

    // Daily matrix buffer for percentiles
    const dayProfitsMatrix: number[][] = Array.from({ length: Math.min(90, days) }, () => []);

    for (let sim = 0; sim < N; sim++) {
      let simBtcPrice = config.btcPriceMean;
      let simDiff = 85.0; // Trillions base
      let simCumulativeProfit = 0;

      for (let d = 0; d < days; d++) {
        // Geometric Brownian Motion for BTC price
        const zBtc = randNorm();
        simBtcPrice = simBtcPrice * Math.exp((btcDriftDay - 0.5 * btcVolDay * btcVolDay) + btcVolDay * zBtc);

        // Difficulty adjustment (every 14 days ~ 0.5% growth average)
        if (d % 14 === 0 && d > 0) {
          const diffChange = (config.difficultyGrowthPercentMonth / 2 / 100) + randNorm() * 0.02;
          simDiff = simDiff * Math.max(0.9, 1 + diffChange);
        }

        // Electricity price stochastic shock
        const elecPrice = config.electricityRateMean * Math.max(0.5, 1 + randNorm() * elecVol);

        // Hardware uptime & temp shock
        const uptime = Math.min(1.0, Math.max(0.85, 0.98 + randNorm() * 0.03));
        const tempShock = config.temperatureAnomalyC + randNorm() * 3.0;

        // Hashrate & Power adjustments based on temp
        const effectiveHashrate = baseHashrateTH * uptime * (1 - Math.max(0, tempShock) * 0.002);
        const effectivePowerKW = basePowerKW * (1 + Math.max(0, tempShock) * 0.003);

        // Calculate Day Economics
        const netHashHps = simDiff * 1e12 * Math.pow(2, 32) / 600;
        const myHps = effectiveHashrate * 1e12;
        const btcMined = (myHps / netHashHps) * 144 * 3.125 * 0.985;
        const revenue = btcMined * simBtcPrice;
        const powerCost = effectivePowerKW * 24 * elecPrice;
        const dayProfit = revenue - powerCost;

        simCumulativeProfit += dayProfit;

        if (d < dayProfitsMatrix.length && sim < 2000) {
          dayProfitsMatrix[d].push(simCumulativeProfit);
        }
      }

      netProfits[sim] = simCumulativeProfit;
      totalProfitsSum += simCumulativeProfit;
      totalProfitsSqSum += simCumulativeProfit * simCumulativeProfit;
      if (simCumulativeProfit < 0) lossCount++;
    }

    // Sort for percentiles
    netProfits.sort((a, b) => a - b);

    const p10Idx = Math.floor(N * 0.1);
    const p50Idx = Math.floor(N * 0.5);
    const p90Idx = Math.floor(N * 0.9);

    const p10NetProfitUSD = netProfits[p10Idx];
    const p50NetProfitUSD = netProfits[p50Idx];
    const p90NetProfitUSD = netProfits[p90Idx];

    const meanNetProfitUSD = totalProfitsSum / N;
    const variance = (totalProfitsSqSum / N) - (meanNetProfitUSD * meanNetProfitUSD);
    const stdDevNetProfitUSD = Math.sqrt(Math.max(0, variance));

    // Sharpe ratio (assuming 4% risk free annual rate converted to period)
    const riskFreeRate = (0.04 / 365) * days * p50NetProfitUSD;
    const sharpeRatio = stdDevNetProfitUSD > 0 ? (meanNetProfitUSD - riskFreeRate) / stdDevNetProfitUSD : 0;

    // Histogram Bins Generation
    const minP = netProfits[0];
    const maxP = netProfits[N - 1];
    const binCount = 20;
    const binWidth = (maxP - minP) / binCount;
    const profitDistribution: { profitBinUSD: number; frequency: number }[] = [];

    for (let i = 0; i < binCount; i++) {
      const binStart = minP + i * binWidth;
      const binEnd = binStart + binWidth;
      const count = netProfits.filter((v) => v >= binStart && v < binEnd).length;
      profitDistribution.push({
        profitBinUSD: Math.round(binStart + binWidth / 2),
        frequency: count,
      });
    }

    // Time series percentile extraction
    const timeSeriesPercentiles = dayProfitsMatrix.map((arr, d) => {
      arr.sort((a, b) => a - b);
      const len = arr.length;
      return {
        day: d + 1,
        p10: Math.round(arr[Math.floor(len * 0.1)] || 0),
        p50: Math.round(arr[Math.floor(len * 0.5)] || 0),
        p90: Math.round(arr[Math.floor(len * 0.9)] || 0),
      };
    });

    return {
      simulationsCount: N,
      p10NetProfitUSD: Math.round(p10NetProfitUSD),
      p50NetProfitUSD: Math.round(p50NetProfitUSD),
      p90NetProfitUSD: Math.round(p90NetProfitUSD),
      meanNetProfitUSD: Math.round(meanNetProfitUSD),
      stdDevNetProfitUSD: Math.round(stdDevNetProfitUSD),
      sharpeRatio: Number(sharpeRatio.toFixed(2)),
      probabilityOfLossPercent: Number(((lossCount / N) * 100).toFixed(1)),
      profitDistribution,
      timeSeriesPercentiles,
    };
  }
}
