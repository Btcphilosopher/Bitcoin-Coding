import { HardwareModel, MinerTelemetry, OperatingProfile, OptimizationTargetOutput } from '../types/mining';
import { HARDWARE_SPECS } from './hardware';

export interface PerformanceCalculationInput {
  model: HardwareModel;
  frequencyMHz: number;
  voltageV: number;
  ambientTempC: number;
  fanSpeedPercent: number;
  siliconQualityScore: number; // 0.85 to 1.15
  ageDays: number;
  btcPriceUSD: number;
  electricityRateKWh: number;
  networkDifficulty: number; // Trillions
}

export class RustPerformanceEngine {
  /**
   * Calculate physical parameters for an ASIC miner under given operating conditions.
   * Based on real physical models of silicon dynamic power, leakage current, fan cubic law,
   * and thermal resistance.
   */
  public static calculatePerformance(input: PerformanceCalculationInput): {
    rawHashrateTH: number;
    effectiveHashrateTH: number;
    asicPowerW: number;
    psuLossW: number;
    fanPowerW: number;
    totalPowerW: number;
    efficiencyJTH: number;
    thPerKW: number;
    asicTempC: number;
    pcbTempC: number;
    hardwareErrorRate: number;
    rejectRatePercent: number;
    thermalMarginC: number;
    failureRiskPercent: number;
    dailyBtcMined: number;
    dailyRevenueUSD: number;
    dailyElectricityCostUSD: number;
    dailyNetProfitUSD: number;
  } {
    const spec = HARDWARE_SPECS[input.model];
    const freq = Math.max(spec.minFreqMHz, Math.min(spec.maxFreqMHz, input.frequencyMHz));
    const volt = Math.max(spec.minVoltageV, Math.min(spec.maxVoltageV, input.voltageV));
    const totalChips = spec.hashBoardsCount * spec.chipsPerBoard;

    // 1. Raw Hashrate Model: Proportional to Frequency * Chip Count * Silicon Quality
    // Base scaling: 110 TH at 600 MHz for S19 Pro
    const nominalRatio = freq / spec.nominalFreqMHz;
    const baseHashrate = spec.nominalHashrateTH * nominalRatio * input.siliconQualityScore;

    // Silicon aging degradation: 0.5% per 365 days
    const ageFactor = 1 - (input.ageDays / 365) * 0.005;
    const rawHashrateTH = baseHashrate * Math.max(0.8, ageFactor);

    // 2. Thermal & Cooling Physics
    // Fan airflow CFM and power (Cubic law: Power ~ RPM^3)
    const fanPct = Math.max(10, Math.min(100, input.fanSpeedPercent));
    const fanRPM = (fanPct / 100) * spec.maxFanRPM;
    const fanPowerW = spec.coolingType === 'AIR' ? 4 * 35 * Math.pow(fanPct / 100, 3) : 80; // 4 fans x 35W max or pump power

    // Dynamic Power P_dyn = C_dyn * V^2 * F
    const vRatio = volt / spec.minVoltageV;
    const dynamicPowerW = spec.nominalPowerW * Math.pow(vRatio, 2.1) * nominalRatio * (1 / input.siliconQualityScore);

    // Initial thermal estimate
    // Thermal resistance R_th reduces with higher fan RPM
    const thermalResistance = spec.coolingType === 'AIR' ? 0.015 * (100 / Math.max(20, fanPct)) : 0.004;
    const estimatedDiePower = dynamicPowerW;
    const tempRise = estimatedDiePower * thermalResistance;
    const pcbTempC = input.ambientTempC + tempRise * 0.65;
    const asicTempC = input.ambientTempC + tempRise;

    // Thermal Leakage Power: Exponential increase above 65°C
    const leakageFactor = Math.exp(0.018 * Math.max(0, asicTempC - 65));
    const asicPowerW = dynamicPowerW * leakageFactor;

    // PSU Loss: Efficiency curve (93.5% peak, drops to 90% at max load or high temp)
    const psuLoadRatio = asicPowerW / spec.nominalPowerW;
    const psuEfficiency = 0.94 - 0.03 * Math.pow(Math.max(0, psuLoadRatio - 0.8), 2);
    const psuLossW = asicPowerW * (1 / psuEfficiency - 1);

    const totalPowerW = asicPowerW + psuLossW + fanPowerW;

    // 3. Hardware Errors & Reject Rates
    // Error rate increases exponentially when voltage is too low for frequency, or temp > 78°C
    const minRequiredVoltsForFreq = spec.minVoltageV + (freq - spec.minFreqMHz) * 0.006;
    const voltageDeficit = Math.max(0, minRequiredVoltsForFreq - volt);
    const thermalStress = Math.max(0, asicTempC - 75);

    const baseErrorRate = 0.0005; // 0.05%
    const errorFromVoltage = Math.pow(voltageDeficit * 8, 3);
    const errorFromTemp = 0.0001 * Math.pow(thermalStress, 2.2);
    const hardwareErrorRate = Math.min(0.25, baseErrorRate + errorFromVoltage + errorFromTemp);

    const rejectRatePercent = 0.3 + 0.1 * (asicTempC > 80 ? 2 : 1) + (hardwareErrorRate > 0.02 ? 1.5 : 0);

    // Effective Hashrate
    const effectiveHashrateTH = rawHashrateTH * (1 - hardwareErrorRate) * (1 - rejectRatePercent / 100);

    // Efficiency & Ratios
    const efficiencyJTH = totalPowerW / Math.max(1, effectiveHashrateTH);
    const thPerKW = (effectiveHashrateTH / (totalPowerW / 1000));
    const thermalMarginC = spec.maxTempASICC - asicTempC;

    // Failure Risk Index (0 - 100%)
    const freqStress = Math.max(0, (freq - spec.nominalFreqMHz) / spec.nominalFreqMHz);
    const failureRiskPercent = Math.min(
      99,
      Math.max(1, (1 - thermalMarginC / 30) * 40 + freqStress * 30 + hardwareErrorRate * 200 + (input.ageDays / 1000) * 10)
    );

    // 4. Financial Economics Calculation
    // Daily BTC mined = (Effective Hashrate TH * 1e12 / Network Hashrate) * 144 blocks * 3.125 BTC
    // Network Hashrate estimation from Difficulty: Hashrate (H/s) = Difficulty * 2^32 / 600
    const netHashrateHps = (input.networkDifficulty * Math.pow(2, 32)) / 600;
    const myHashrateHps = effectiveHashrateTH * 1e12;
    const shareOfNetwork = myHashrateHps / netHashrateHps;
    const dailyBtcMined = shareOfNetwork * 144 * 3.125 * (1 - 0.015); // 1.5% pool fee

    const dailyRevenueUSD = dailyBtcMined * input.btcPriceUSD;
    const dailyKWh = (totalPowerW * 24) / 1000;
    const dailyElectricityCostUSD = dailyKWh * input.electricityRateKWh;
    const dailyNetProfitUSD = dailyRevenueUSD - dailyElectricityCostUSD;

    return {
      rawHashrateTH,
      effectiveHashrateTH,
      asicPowerW,
      psuLossW,
      fanPowerW,
      totalPowerW,
      efficiencyJTH,
      thPerKW,
      asicTempC,
      pcbTempC,
      hardwareErrorRate,
      rejectRatePercent,
      thermalMarginC,
      failureRiskPercent,
      dailyBtcMined,
      dailyRevenueUSD,
      dailyElectricityCostUSD,
      dailyNetProfitUSD,
    };
  }

  /**
   * Find optimal operating point (Frequency, Voltage, Fan) for a target profile
   * under strict safety constraints.
   */
  public static optimizeOperatingPoint(
    model: HardwareModel,
    profile: OperatingProfile,
    ambientTempC: number,
    electricityRateKWh: number,
    btcPriceUSD: number,
    networkDifficulty: number,
    siliconQualityScore: number = 1.0,
    ageDays: number = 180
  ): OptimizationTargetOutput {
    const spec = HARDWARE_SPECS[model];

    let bestFreq = spec.nominalFreqMHz;
    let bestVoltage = spec.minVoltageV + (spec.maxVoltageV - spec.minVoltageV) * 0.5;
    let bestFan = 80;
    let maxObjectiveScore = -Infinity;
    let bestPerf = this.calculatePerformance({
      model,
      frequencyMHz: bestFreq,
      voltageV: bestVoltage,
      ambientTempC,
      fanSpeedPercent: bestFan,
      siliconQualityScore,
      ageDays,
      btcPriceUSD,
      electricityRateKWh,
      networkDifficulty,
    });

    // Grid search over permitted frequency and voltage spectrum
    const freqSteps = 15;
    const voltSteps = 10;
    const freqStepSize = (spec.maxFreqMHz - spec.minFreqMHz) / freqSteps;
    const voltStepSize = (spec.maxVoltageV - spec.minVoltageV) / voltSteps;

    for (let fIdx = 0; fIdx <= freqSteps; fIdx++) {
      const freq = spec.minFreqMHz + fIdx * freqStepSize;

      for (let vIdx = 0; vIdx <= voltSteps; vIdx++) {
        const volt = spec.minVoltageV + vIdx * voltStepSize;

        // Auto fan curve targeting 68°C die temp
        const requiredFan = Math.min(100, Math.max(30, 50 + (freq - spec.nominalFreqMHz) * 0.15 + (ambientTempC - 20) * 1.5));

        const perf = this.calculatePerformance({
          model,
          frequencyMHz: freq,
          voltageV: volt,
          ambientTempC,
          fanSpeedPercent: requiredFan,
          siliconQualityScore,
          ageDays,
          btcPriceUSD,
          electricityRateKWh,
          networkDifficulty,
        });

        // SAFETY CONSTRAINTS FILTER
        if (perf.asicTempC > spec.maxTempASICC - 3) continue; // 3°C thermal safety margin
        if (perf.hardwareErrorRate > 0.02) continue; // Max 2% error rate
        if (perf.totalPowerW > spec.nominalPowerW * 1.3) continue; // Max 130% PSU rating

        // Multi-Objective Scoring by Profile
        let score = 0;

        switch (profile) {
          case 'EFFICIENCY': // Minimize J/TH
            score = -perf.efficiencyJTH + perf.dailyNetProfitUSD * 2;
            break;
          case 'HASHRATE': // Maximize TH/s safely
            score = perf.effectiveHashrateTH * 10 - perf.failureRiskPercent * 2;
            break;
          case 'PROFIT': // Maximize Net Daily Revenue minus power
            score = perf.dailyNetProfitUSD * 50 - perf.failureRiskPercent * 0.5;
            break;
          case 'LONGEVITY': // Maximize thermal margin and low stress
            score = perf.thermalMarginC * 5 - perf.hardwareErrorRate * 1000 + perf.dailyNetProfitUSD * 10;
            break;
          case 'BALANCED': // Balanced efficiency & profit
          default:
            score = perf.dailyNetProfitUSD * 30 - perf.efficiencyJTH * 0.8 - perf.failureRiskPercent * 0.5;
            break;
        }

        if (score > maxObjectiveScore) {
          maxObjectiveScore = score;
          bestFreq = freq;
          bestVoltage = volt;
          bestFan = requiredFan;
          bestPerf = perf;
        }
      }
    }

    const marginPct = (bestPerf.dailyNetProfitUSD * 0.1) / Math.max(1, bestPerf.dailyRevenueUSD);
    const ci95Min = Math.max(0, bestPerf.dailyNetProfitUSD * (1 - marginPct));
    const ci95Max = bestPerf.dailyNetProfitUSD * (1 + marginPct);

    return {
      minerId: `${model}_OPT`,
      model,
      targetFreqMHz: Math.round(bestFreq),
      targetVoltageV: Number(bestVoltage.toFixed(2)),
      targetHashrateTH: Number(bestPerf.effectiveHashrateTH.toFixed(2)),
      targetPowerW: Math.round(bestPerf.totalPowerW),
      targetFanRPM: Math.round((bestFan / 100) * spec.maxFanRPM),
      expectedJTH: Number(bestPerf.efficiencyJTH.toFixed(2)),
      expectedTempC: Number(bestPerf.asicTempC.toFixed(1)),
      expectedErrorRatePercent: Number((bestPerf.hardwareErrorRate * 100).toFixed(3)),
      expectedDailyBtc: Number(bestPerf.dailyBtcMined.toFixed(6)),
      expectedDailyRevenueUSD: Number(bestPerf.dailyRevenueUSD.toFixed(2)),
      expectedDailyElectricityCostUSD: Number(bestPerf.dailyElectricityCostUSD.toFixed(2)),
      expectedDailyProfitUSD: Number(bestPerf.dailyNetProfitUSD.toFixed(2)),
      expectedHardwareRiskPercent: Number(bestPerf.failureRiskPercent.toFixed(1)),
      confidenceInterval95: [Number(ci95Min.toFixed(2)), Number(ci95Max.toFixed(2))],
    };
  }
}
