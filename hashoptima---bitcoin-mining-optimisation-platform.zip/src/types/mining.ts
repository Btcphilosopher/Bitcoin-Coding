/**
 * Bitcoin Mining Performance Optimisation Platform - Types & Interfaces
 */

export type OperatingProfile = 'EFFICIENCY' | 'BALANCED' | 'HASHRATE' | 'PROFIT' | 'LONGEVITY';

export type DispatchState = 'FULL_POWER' | 'REDUCED_POWER' | 'STANDBY' | 'OFFLINE';

export type HardwareModel = 'ANTMINER_S19_PRO' | 'ANTMINER_S19_XP' | 'ANTMINER_S21' | 'ANTMINER_S21_HYDRO' | 'WHATSMINER_M50S';

export interface HardwareSpec {
  model: HardwareModel;
  displayName: string;
  nominalHashrateTH: number; // TH/s
  nominalPowerW: number; // Watts
  nominalEfficiencyJTH: number; // J/TH
  hashBoardsCount: number;
  chipsPerBoard: number;
  minFreqMHz: number;
  maxFreqMHz: number;
  nominalFreqMHz: number;
  minVoltageV: number;
  maxVoltageV: number;
  maxTempASICC: number; // Thermal protection trip limit °C
  maxTempPCBC: number;
  maxFanRPM: number;
  coolingType: 'AIR' | 'IMMERSION' | 'HYDRO';
  firmwareSupport: string[];
}

export interface ASICBoardTelemetry {
  boardId: number;
  status: 'OK' | 'WARNING' | 'ERROR' | 'DISABLED';
  temperatureASIC: number; // °C
  temperaturePCB: number; // °C
  frequencyMHz: number;
  voltageV: number;
  hashrateTH: number;
  hardwareErrors: number;
  chipCountActive: number;
  chipCountTotal: number;
}

export interface MinerTelemetry {
  minerId: string;
  ipAddress: string;
  model: HardwareModel;
  serialNumber: string;
  uptimeSeconds: number;
  operatingMode: OperatingProfile;
  dispatchState: DispatchState;
  
  // Hashrate
  instantHashrateTH: number;
  rolling5mHashrateTH: number;
  rolling15mHashrateTH: number;
  rolling1hHashrateTH: number;
  effectiveHashrateTH: number;
  
  // Power & Efficiency
  asicPowerW: number;
  psuLossW: number;
  fanPowerW: number;
  totalPowerW: number;
  efficiencyJTH: number;
  thPerKW: number;
  
  // Thermal & Fans
  ambientTempC: number;
  intakeTempC: number;
  exhaustTempC: number;
  maxASICTempC: number;
  maxPCBTempC: number;
  fanSpeedRPM: number;
  fanSpeedPercent: number;
  thermalMarginC: number;
  
  // Health & Errors
  hardwareErrors: number;
  hardwareErrorRate: number; // errors / second
  acceptedShares: number;
  rejectedShares: number;
  rejectRatePercent: number;
  poolLatencyMs: number;
  
  // Boards
  boards: ASICBoardTelemetry[];
  
  // Meta
  ageDays: number;
  siliconQualityScore: number; // 0.8 to 1.2 (silicon lottery multiplier)
  failureRiskPercent: number;
}

export interface FleetSummary {
  totalMinersCount: number;
  activeCount: number;
  reducedPowerCount: number;
  standbyCount: number;
  offlineCount: number;
  
  totalHashrateTH: number;
  totalPowerKW: number;
  facilityOverheadKW: number;
  coolingPowerKW: number;
  grandTotalPowerKW: number;
  
  effectiveEfficiencyJTH: number;
  averageASICTempC: number;
  averageErrorRate: number;
  averageUptimePercent: number;
  
  // Daily Financials (R Economics)
  btcPriceUSD: number;
  networkDifficulty: number; // in Trillions (or raw)
  networkHashrateEH: number;
  dailyBtcMined: number;
  dailyRevenueUSD: number;
  dailyElectricityCostUSD: number;
  dailyCoolingCostUSD: number;
  dailyFacilityOverheadUSD: number;
  dailyNetProfitUSD: number;
  profitPerKWhUSD: number;
  profitPerTHUSD: number;
}

export interface DynamicHourlyTariff {
  hour: number; // 0..23
  electricityRateKWh: number; // $ / kWh
  expectedBtcPriceUSD: number;
  expectedRevenueUSD: number;
  expectedPowerCostUSD: number;
  expectedProfitUSD: number;
  recommendedState: DispatchState;
}

export interface MonteCarloConfig {
  simulationsCount: number; // e.g. 10000, 100000
  timeHorizonDays: number; // 30, 90, 365
  btcPriceMean: number;
  btcPriceVolatilityPercent: number;
  difficultyGrowthPercentMonth: number;
  electricityRateMean: number;
  electricityRateVolPercent: number;
  temperatureAnomalyC: number;
}

export interface MonteCarloResult {
  simulationsCount: number;
  p10NetProfitUSD: number;
  p50NetProfitUSD: number; // Median
  p90NetProfitUSD: number;
  meanNetProfitUSD: number;
  stdDevNetProfitUSD: number;
  sharpeRatio: number;
  probabilityOfLossPercent: number;
  profitDistribution: { profitBinUSD: number; frequency: number }[];
  timeSeriesPercentiles: {
    day: number;
    p10: number;
    p50: number;
    p90: number;
  }[];
}

export interface SensitivityMetric {
  variableName: string;
  category: 'MARKET' | 'HARDWARE' | 'ENVIRONMENT' | 'OPERATIONAL';
  pearsonCorrelation: number;
  spearmanCorrelation: number;
  sobolFirstOrderIndex: number;
  sobolTotalEffectIndex: number;
  varianceContributionPercent: number;
  rank: number;
}

export interface AdaptiveControlStep {
  stepId: string;
  timestamp: string;
  phase: 'OBSERVE' | 'SIMULATE' | 'PREDICT' | 'MAKE_SMALL_CHANGE' | 'OBSERVE_POST' | 'COMPARE' | 'ACCEPT' | 'REVERT';
  minerId: string;
  parameterName: string;
  previousValue: number;
  proposedValue: number;
  predictedHashrateTH: number;
  predictedTempC: number;
  predictedProfitUSD: number;
  actualHashrateTH?: number;
  actualTempC?: number;
  actualErrorRate?: number;
  decision: 'PENDING' | 'ACCEPTED' | 'REVERTED' | 'SAFETY_TRIP';
  reason: string;
}

export interface OptimizationTargetOutput {
  minerId: string;
  model: HardwareModel;
  targetFreqMHz: number;
  targetVoltageV: number;
  targetHashrateTH: number;
  targetPowerW: number;
  targetFanRPM: number;
  expectedJTH: number;
  expectedTempC: number;
  expectedErrorRatePercent: number;
  expectedDailyBtc: number;
  expectedDailyRevenueUSD: number;
  expectedDailyElectricityCostUSD: number;
  expectedDailyProfitUSD: number;
  expectedHardwareRiskPercent: number;
  confidenceInterval95: [number, number];
}
